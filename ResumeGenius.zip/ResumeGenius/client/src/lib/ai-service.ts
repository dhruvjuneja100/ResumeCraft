import { apiRequest } from "./queryClient";
import { ResumeContent } from "@shared/schema";

/**
 * Service for interacting with AI-related functionality
 */
export const aiService = {
  /**
   * Analyze a resume for ATS optimization
   */
  analyzeResume: async (resumeContent: ResumeContent) => {
    try {
      const response = await apiRequest("POST", "/api/ats/analyze", {
        resumeContent,
      });
      return await response.json();
    } catch (error) {
      console.error("Error analyzing resume:", error);
      throw error;
    }
  },

  /**
   * Enhance a specific resume section using AI
   */
  enhanceSection: async (
    sectionType: string,
    sectionContent: any,
    jobDescription?: string
  ) => {
    try {
      const response = await apiRequest("POST", "/api/ai/enhance", {
        sectionType,
        sectionContent,
        jobDescription,
      });
      return await response.json();
    } catch (error) {
      console.error("Error enhancing section:", error);
      throw error;
    }
  },

  /**
   * Match a resume against a job description
   */
  matchJobDescription: async (
    resumeContent: ResumeContent,
    jobDescription: string
  ) => {
    try {
      const response = await apiRequest("POST", "/api/job/match", {
        resumeContent,
        jobDescription,
      });
      return await response.json();
    } catch (error) {
      console.error("Error matching job description:", error);
      throw error;
    }
  },

  /**
   * Generate achievement suggestions based on job description
   */
  generateAchievements: async (
    position: string,
    description: string,
    jobDescription?: string
  ) => {
    try {
      const response = await apiRequest("POST", "/api/ai/enhance", {
        sectionType: "achievements",
        sectionContent: {
          position,
          description,
        },
        jobDescription,
      });
      return await response.json();
    } catch (error) {
      console.error("Error generating achievements:", error);
      throw error;
    }
  },

  /**
   * Generate skill suggestions based on resume content and job description
   */
  suggestSkills: async (
    resumeContent: ResumeContent,
    jobDescription?: string
  ) => {
    try {
      const response = await apiRequest("POST", "/api/ai/enhance", {
        sectionType: "skills",
        sectionContent: resumeContent.skills,
        jobDescription,
      });
      return await response.json();
    } catch (error) {
      console.error("Error suggesting skills:", error);
      throw error;
    }
  },
};

export default aiService;
