import React, { useState } from "react";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { KeywordBadge } from "@/components/resume/keyword-badge";
import { Progress } from "@/components/ui/progress";
import { InfoIcon, Download } from "lucide-react";
import { apiRequest } from "@/lib/queryClient";
import { ResumeContent } from "@shared/schema";

interface JobDescriptionMatcherProps {
  isOpen: boolean;
  onClose: () => void;
  resumeContent: ResumeContent;
  onApplyRecommendations: (recommendations: any) => void;
}

export function JobDescriptionMatcher({
  isOpen,
  onClose,
  resumeContent,
  onApplyRecommendations,
}: JobDescriptionMatcherProps) {
  const [jobDescription, setJobDescription] = useState("");
  const [jobUrl, setJobUrl] = useState("");
  const [isAnalyzing, setIsAnalyzing] = useState(false);
  const [analysis, setAnalysis] = useState<{
    matchScore: number;
    matchedKeywords: string[];
    missingKeywords: string[];
    recommendations: string[];
  } | null>(null);

  const handleAnalyze = async () => {
    if (!jobDescription) return;

    setIsAnalyzing(true);
    try {
      const response = await apiRequest("POST", "/api/job/match", {
        resumeContent,
        jobDescription,
      });
      
      const result = await response.json();
      setAnalysis(result);
    } catch (error) {
      console.error("Error analyzing job match:", error);
    } finally {
      setIsAnalyzing(false);
    }
  };

  const handleUrlFetch = async () => {
    if (!jobUrl) return;
    
    // In a real implementation, this would scrape the job description from the URL
    // For this demo, we'll just set a placeholder
    setJobDescription(
      "Looking for a Senior Frontend Developer with experience in React, TypeScript, and modern JavaScript. Must have 5+ years of experience building responsive web applications and leading development teams. Experience with CI/CD pipelines, performance optimization, and unit testing required."
    );
  };

  const handleApplyRecommendations = () => {
    if (analysis) {
      onApplyRecommendations(analysis);
      onClose();
    }
  };

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="max-w-2xl max-h-[90vh] flex flex-col">
        <DialogHeader>
          <DialogTitle>Job Description Matcher</DialogTitle>
        </DialogHeader>
        
        <div className="flex-1 overflow-auto p-4">
          <div className="mb-4">
            <label className="block text-sm font-medium text-gray-700 mb-1">
              Paste Job Description
            </label>
            <Textarea
              rows={6}
              placeholder="Paste the job description here..."
              value={jobDescription}
              onChange={(e) => setJobDescription(e.target.value)}
              className="resize-none"
            />
          </div>
          
          <div className="mb-4">
            <label className="block text-sm font-medium text-gray-700 mb-1">
              Or Enter Job URL
            </label>
            <div className="flex">
              <Input
                type="text"
                placeholder="https://example.com/job-posting"
                className="rounded-l-md"
                value={jobUrl}
                onChange={(e) => setJobUrl(e.target.value)}
              />
              <Button
                className="rounded-l-none"
                onClick={handleUrlFetch}
                disabled={!jobUrl}
              >
                <Download className="h-4 w-4" />
              </Button>
            </div>
          </div>
          
          <Button 
            className="w-full mb-4" 
            onClick={handleAnalyze} 
            disabled={!jobDescription || isAnalyzing}
          >
            {isAnalyzing ? "Analyzing..." : "Analyze Match"}
          </Button>
          
          {analysis && (
            <div className="bg-gray-50 rounded-lg p-4">
              <h3 className="text-sm font-medium text-gray-700 mb-2">Match Analysis</h3>
              <div className="flex items-center mb-3">
                <div className="w-24 text-sm text-gray-500">Match Score:</div>
                <div className="flex-1">
                  <Progress value={analysis.matchScore} className="h-2" />
                </div>
                <div className="ml-2 text-sm font-medium text-yellow-600">{analysis.matchScore}%</div>
              </div>
              
              {analysis.matchedKeywords.length > 0 && (
                <>
                  <h4 className="text-sm font-medium text-gray-700 mt-3 mb-2">Matched Keywords</h4>
                  <div className="flex flex-wrap gap-2 mb-3">
                    {analysis.matchedKeywords.map((keyword, index) => (
                      <KeywordBadge
                        key={index}
                        keyword={keyword}
                        status="matched"
                      />
                    ))}
                  </div>
                </>
              )}
              
              {analysis.missingKeywords.length > 0 && (
                <>
                  <h4 className="text-sm font-medium text-gray-700 mt-3 mb-2">Missing Keywords</h4>
                  <div className="flex flex-wrap gap-2 mb-3">
                    {analysis.missingKeywords.map((keyword, index) => (
                      <KeywordBadge
                        key={index}
                        keyword={keyword}
                        status="missing"
                        onAdd={() => {
                          // In a real implementation, this would add the keyword to the resume
                        }}
                      />
                    ))}
                  </div>
                </>
              )}
              
              {analysis.recommendations.length > 0 && (
                <>
                  <h4 className="text-sm font-medium text-gray-700 mt-3 mb-2">Recommended Improvements</h4>
                  <ul className="text-sm text-gray-700 space-y-2">
                    {analysis.recommendations.map((rec, index) => (
                      <li key={index} className="flex items-start">
                        <InfoIcon className="text-blue-500 h-4 w-4 mt-1 mr-2" />
                        <span>{rec}</span>
                      </li>
                    ))}
                  </ul>
                </>
              )}
            </div>
          )}
        </div>
        
        <DialogFooter>
          <Button variant="outline" onClick={onClose} className="mr-2">
            Cancel
          </Button>
          <Button 
            onClick={handleApplyRecommendations} 
            disabled={!analysis}
          >
            Apply Recommendations
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}
