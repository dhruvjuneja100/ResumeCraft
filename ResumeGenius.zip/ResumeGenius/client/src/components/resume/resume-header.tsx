import React from "react";
import { Button } from "@/components/ui/button";
import { Share, Save, User } from "lucide-react";
import { cn } from "@/lib/utils";

interface ResumeHeaderProps {
  username?: string;
  avatarUrl?: string;
  onSave: () => void;
  onShare?: () => void;
  className?: string;
}

export function ResumeHeader({
  username = "User",
  avatarUrl,
  onSave,
  onShare,
  className,
}: ResumeHeaderProps) {
  return (
    <header
      className={cn(
        "bg-white border-b border-gray-200 px-4 py-3 flex items-center justify-between",
        className
      )}
    >
      <div className="flex items-center space-x-4">
        <div className="flex items-center">
          <svg
            className="w-8 h-8 text-primary"
            fill="currentColor"
            viewBox="0 0 24 24"
          >
            <path d="M19 5v14H5V5h14m0-2H5c-1.1 0-2 .9-2 2v14c0 1.1.9 2 2 2h14c1.1 0 2-.9 2-2V5c0-1.1-.9-2-2-2z" />
            <path d="M14 17H7v-2h7v2zm3-4H7v-2h10v2zm0-4H7V7h10v2z" />
          </svg>
          <span className="ml-2 text-xl font-bold text-gray-900">Resume Craft</span>
        </div>
        <nav className="hidden md:flex space-x-6">
          <a href="#" className="text-primary font-medium">
            Builder
          </a>
          <a href="#" className="text-gray-500 hover:text-gray-900">
            Templates
          </a>
          <a href="#" className="text-gray-500 hover:text-gray-900">
            ATS Checker
          </a>
          <a href="#" className="text-gray-500 hover:text-gray-900">
            Job Matcher
          </a>
        </nav>
      </div>
      <div className="flex items-center space-x-4">
        {onShare && (
          <Button
            variant="outline"
            size="sm"
            className="hidden sm:inline-flex"
            onClick={onShare}
          >
            <Share className="w-4 h-4 mr-2" />
            Share
          </Button>
        )}
        <Button size="sm" onClick={onSave}>
          <Save className="w-4 h-4 mr-2" />
          Save
        </Button>
        <div className="relative">
          <Button
            variant="ghost"
            className="bg-gray-800 flex text-sm rounded-full focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-primary"
            size="icon"
          >
            <span className="sr-only">Open user menu</span>
            {avatarUrl ? (
              <img
                className="h-8 w-8 rounded-full"
                src={avatarUrl}
                alt="User avatar"
              />
            ) : (
              <User className="h-5 w-5 text-white" />
            )}
          </Button>
        </div>
      </div>
    </header>
  );
}
