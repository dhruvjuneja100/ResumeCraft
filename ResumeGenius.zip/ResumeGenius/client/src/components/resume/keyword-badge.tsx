import React from "react";
import { cn } from "@/lib/utils";
import { Check, Plus } from "lucide-react";

type KeywordStatus = "matched" | "missing" | "suggested";

interface KeywordBadgeProps {
  keyword: string;
  status: KeywordStatus;
  onAdd?: () => void;
  className?: string;
}

export function KeywordBadge({
  keyword,
  status,
  onAdd,
  className,
}: KeywordBadgeProps) {
  // Determine styles based on status
  const getBadgeStyles = () => {
    switch (status) {
      case "matched":
        return "bg-green-100 text-green-800";
      case "missing":
        return "bg-red-100 text-red-800";
      case "suggested":
        return "bg-gray-100 text-gray-800";
      default:
        return "bg-gray-100 text-gray-800";
    }
  };

  const getIconStyles = () => {
    switch (status) {
      case "matched":
        return "text-green-600";
      case "missing":
        return "text-red-600";
      case "suggested":
        return "text-gray-500";
      default:
        return "text-gray-500";
    }
  };

  return (
    <div
      className={cn(
        "inline-flex items-center px-2 py-1 rounded-full text-xs font-medium",
        getBadgeStyles(),
        className
      )}
    >
      {keyword}
      {status === "matched" && (
        <Check className={cn("h-3 w-3 ml-1", getIconStyles())} />
      )}
      {(status === "missing" || status === "suggested") && onAdd && (
        <button
          className={cn("ml-1", getIconStyles())}
          onClick={onAdd}
        >
          <Plus className="h-3 w-3" />
        </button>
      )}
    </div>
  );
}
