import React, { useEffect, useState, useRef } from "react";
import { Button } from "@/components/ui/button";
import { Download, Laptop, Smartphone, Tablet, FileText } from "lucide-react";
import { cn } from "@/lib/utils";
import { generatePDF, setPdfExportComponent } from "@/lib/pdf-generator";
import { ResumeContent } from "@shared/schema";
import { PDFExport } from "@progress/kendo-react-pdf";
import { ResumeTemplate } from "./resume-template";
import { useToast } from "@/hooks/use-toast";

interface PDFViewerProps {
  resumeContent: ResumeContent;
  templateStyle?: any;
  className?: string;
}

export function PDFViewer({
  resumeContent,
  templateStyle,
  className,
}: PDFViewerProps) {
  const [viewMode, setViewMode] = useState<"desktop" | "tablet" | "mobile">(
    "desktop"
  );
  const [pdfUrl, setPdfUrl] = useState<string | null>(null);
  const [isGenerating, setIsGenerating] = useState(false);
  const pdfExportRef = useRef<PDFExport | null>(null);
  const { toast } = useToast();

  // Set PDF export component ref
  useEffect(() => {
    if (pdfExportRef.current) {
      setPdfExportComponent(pdfExportRef.current);
    }
    
    return () => {
      setPdfExportComponent(null);
    };
  }, [pdfExportRef]);

  // Handle export to PDF
  const handleExport = async () => {
    setIsGenerating(true);
    try {
      const filename = `${resumeContent.personalInfo.fullName.replace(/\s+/g, '_')}_Resume.pdf`;
      const result = await generatePDF(resumeContent, templateStyle, filename);
      
      toast({
        title: "Resume exported",
        description: "Your resume has been exported as a PDF.",
      });
    } catch (error) {
      console.error("Error generating PDF:", error);
      toast({
        title: "Export failed",
        description: "There was an error exporting your resume. Please try again.",
        variant: "destructive"
      });
    } finally {
      setIsGenerating(false);
    }
  };

  // Determine width based on view mode
  const getViewportWidth = () => {
    switch (viewMode) {
      case "desktop":
        return "100%";
      case "tablet":
        return "768px";
      case "mobile":
        return "375px";
      default:
        return "100%";
    }
  };

  return (
    <div className={cn("flex flex-col h-full", className)}>
      {/* Preview Header */}
      <div className="p-4 border-b border-gray-200 flex items-center justify-between">
        <h2 className="text-lg font-medium text-gray-900">Live Preview</h2>
        <div className="flex items-center space-x-2">
          <Button
            variant={viewMode === "desktop" ? "secondary" : "ghost"}
            size="icon"
            title="Desktop view"
            onClick={() => setViewMode("desktop")}
          >
            <Laptop className="h-4 w-4" />
          </Button>
          <Button
            variant={viewMode === "tablet" ? "secondary" : "ghost"}
            size="icon"
            title="Tablet view"
            onClick={() => setViewMode("tablet")}
          >
            <Tablet className="h-4 w-4" />
          </Button>
          <Button
            variant={viewMode === "mobile" ? "secondary" : "ghost"}
            size="icon"
            title="Mobile view"
            onClick={() => setViewMode("mobile")}
          >
            <Smartphone className="h-4 w-4" />
          </Button>
          <Button
            className="ml-2"
            size="sm"
            onClick={handleExport}
            disabled={isGenerating}
          >
            <Download className="h-4 w-4 mr-1" />
            {isGenerating ? "Generating..." : "Export PDF"}
          </Button>
        </div>
      </div>

      {/* Resume Preview with PDF Export Component */}
      <div className="flex-1 overflow-auto p-6">
        <div
          style={{
            width: getViewportWidth(),
            margin: "0 auto",
            transition: "width 0.3s ease",
          }}
          className={cn("bg-white border border-gray-200 shadow-sm", {
            "mx-auto": viewMode !== "desktop",
          })}
        >
          {/* PDF Export Container */}
          <PDFExport
            ref={pdfExportRef}
            paperSize="A4"
            margin="1cm"
            fileName={`${resumeContent.personalInfo.fullName.replace(/\s+/g, '_')}_Resume.pdf`}
            author="Resume Craft"
            scale={0.8}
          >
            <div className="pdf-export-container p-8">
              <ResumeTemplate
                content={resumeContent}
                templateStyle={templateStyle}
              />
            </div>
          </PDFExport>
        </div>
      </div>
    </div>
  );
}
