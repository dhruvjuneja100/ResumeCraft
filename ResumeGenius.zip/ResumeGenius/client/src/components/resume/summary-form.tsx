import React, { useState } from 'react';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Button } from '@/components/ui/button';
import { Card } from '@/components/ui/card';
import { Save } from 'lucide-react';

interface SummaryFormProps {
  summary: string;
  onUpdate: (summary: string) => void;
}

export function SummaryForm({ summary, onUpdate }: SummaryFormProps) {
  const [value, setValue] = useState(summary);
  const [isEditing, setIsEditing] = useState(false);
  
  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    onUpdate(value);
    setIsEditing(false);
  };

  return (
    <Card className="p-6 shadow-sm">
      <form onSubmit={handleSubmit}>
        <div className="space-y-4">
          <div className="flex justify-between items-center">
            <Label htmlFor="summary" className="text-lg font-medium">
              Professional Summary
            </Label>
            {!isEditing && summary && (
              <Button
                type="button"
                variant="outline"
                size="sm"
                onClick={() => setIsEditing(true)}
              >
                Edit
              </Button>
            )}
          </div>
          
          {isEditing || !summary ? (
            <>
              <Textarea
                id="summary"
                value={value}
                onChange={(e) => setValue(e.target.value)}
                placeholder="Write a brief overview of your professional background, key skills, and career objectives. Keep it concise, focused, and tailored to your target role."
                className="min-h-[150px]"
              />
              
              <div className="flex justify-end space-x-2">
                {summary && (
                  <Button
                    type="button"
                    variant="outline"
                    onClick={() => {
                      setValue(summary);
                      setIsEditing(false);
                    }}
                  >
                    Cancel
                  </Button>
                )}
                <Button type="submit">
                  <Save className="w-4 h-4 mr-2" />
                  Save
                </Button>
              </div>
            </>
          ) : (
            <div className="mt-2 p-4 bg-gray-50 rounded-md min-h-[100px] whitespace-pre-wrap">
              {summary}
            </div>
          )}
        </div>
      </form>
    </Card>
  );
}