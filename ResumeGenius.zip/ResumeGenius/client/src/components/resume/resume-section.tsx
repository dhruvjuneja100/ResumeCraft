import React, { useState, useRef } from "react";
import { Card, CardContent } from "@/components/ui/card";
import { ChevronDown, ChevronRight, GripVertical } from "lucide-react";
import { cn } from "@/lib/utils";

interface ResumeSectionProps {
  id: string;
  title: string;
  description: string;
  isExpanded?: boolean;
  isDragging?: boolean;
  onToggleExpand: () => void;
  children: React.ReactNode;
}

export function ResumeSection({
  id,
  title,
  description,
  isExpanded = false,
  isDragging = false,
  onToggleExpand,
  children,
}: ResumeSectionProps) {
  const [isHovered, setIsHovered] = useState(false);
  const sectionRef = useRef<HTMLDivElement>(null);

  return (
    <div
      ref={sectionRef}
      className={cn(
        "draggable-item p-3 bg-white rounded-md shadow-sm border transition-all",
        isHovered ? "border-primary-300 shadow" : "border-gray-200",
        isDragging ? "opacity-50" : "opacity-100"
      )}
      onMouseEnter={() => setIsHovered(true)}
      onMouseLeave={() => setIsHovered(false)}
      draggable
      data-section-id={id}
    >
      <div className="flex items-center">
        <GripVertical className="w-5 h-5 text-gray-400 mr-3 cursor-grab" />
        <div className="flex-1">
          <h3 className="text-sm font-medium text-gray-900">{title}</h3>
          <p className="text-xs text-gray-500">{description}</p>
        </div>
        <button
          className="text-gray-400 hover:text-gray-600"
          onClick={onToggleExpand}
        >
          {isExpanded ? (
            <ChevronDown className="w-5 h-5" />
          ) : (
            <ChevronRight className="w-5 h-5" />
          )}
        </button>
      </div>

      {isExpanded && (
        <div className="pt-3 mt-3 border-t border-gray-100">{children}</div>
      )}
    </div>
  );
}
