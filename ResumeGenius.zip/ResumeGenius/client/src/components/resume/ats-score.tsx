import React from "react";
import { Button } from "@/components/ui/button";
import { AlertCircle, CheckCircle } from "lucide-react";
import { cn } from "@/lib/utils";

interface ATSScoreProps {
  score: number;
  analysis: string;
  onRunFullCheck?: () => void;
  className?: string;
}

export function ATSScore({
  score,
  analysis,
  onRunFullCheck,
  className,
}: ATSScoreProps) {
  // Determine color and icon based on score
  const getScoreColor = () => {
    if (score >= 80) return "bg-green-500";
    if (score >= 60) return "bg-yellow-500";
    return "bg-red-500";
  };

  const getScoreText = () => {
    if (score >= 80) return "text-green-500";
    if (score >= 60) return "text-yellow-500";
    return "text-red-500";
  };

  const getScoreIcon = () => {
    if (score >= 70) return <CheckCircle className="h-4 w-4 mr-1" />;
    return <AlertCircle className="h-4 w-4 mr-1" />;
  };

  return (
    <div
      className={cn(
        "bg-gray-50 p-3 rounded-lg border border-gray-200",
        className
      )}
    >
      <div className="flex items-center justify-between">
        <h3 className="text-sm font-medium text-gray-900">ATS Score</h3>
        <span className={cn("text-sm font-semibold", getScoreText())}>
          {score}/100
        </span>
      </div>
      <div className="mt-2 relative h-2 rounded-full bg-gray-200">
        <div
          className={cn("absolute left-0 top-0 h-2 rounded-full", getScoreColor())}
          style={{ width: `${score}%` }}
        ></div>
      </div>
      <p className="mt-2 text-xs text-gray-600">{analysis}</p>
      {onRunFullCheck && (
        <Button
          variant="outline"
          size="sm"
          className="mt-2 w-full bg-primary-50 text-primary hover:bg-primary-100"
          onClick={onRunFullCheck}
        >
          Run Full ATS Check
        </Button>
      )}
    </div>
  );
}
