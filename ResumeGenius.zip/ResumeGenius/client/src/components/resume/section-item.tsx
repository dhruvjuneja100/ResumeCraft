import React from "react";
import {
  Card,
  CardContent,
  CardDescription,
  CardFooter,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Copy, Save, Trash2, ChevronDown } from "lucide-react";
import { AISuggestion } from "./ai-suggestion";

interface SectionItemProps {
  id: string;
  isCollapsed?: boolean;
  onToggleCollapse: () => void;
  onDuplicate: () => void;
  onDelete: () => void;
  onSave: () => void;
  children: React.ReactNode;
  title: string;
  subtitle?: string;
  date?: string;
  aiSuggestions?: string[];
  showAiSuggestions?: boolean;
}

export function SectionItem({
  id,
  isCollapsed = false,
  onToggleCollapse,
  onDuplicate,
  onDelete,
  onSave,
  children,
  title,
  subtitle,
  date,
  aiSuggestions,
  showAiSuggestions = false,
}: SectionItemProps) {
  if (isCollapsed) {
    return (
      <Card className="mb-4">
        <CardContent className="p-4">
          <div className="flex items-center justify-between">
            <div>
              <h3 className="text-base font-medium text-gray-900">{title}</h3>
              <div className="text-sm text-gray-600">
                {subtitle} {date && `• ${date}`}
              </div>
            </div>
            <button
              className="text-gray-400 hover:text-gray-600"
              onClick={onToggleCollapse}
            >
              <ChevronDown className="w-5 h-5 rotate-270" />
            </button>
          </div>
        </CardContent>
      </Card>
    );
  }

  return (
    <Card className="mb-6">
      <CardContent className="pt-5">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between mb-4">
          <div>
            <div className="flex items-center">
              <h3 className="text-lg font-medium text-gray-900">{title}</h3>
              {subtitle && subtitle.toLowerCase().includes("current") && (
                <div className="ml-2 px-2 py-0.5 text-xs font-medium bg-primary-100 text-primary-800 rounded">
                  Current
                </div>
              )}
            </div>
            <div className="mt-1 text-sm text-gray-600">{subtitle}</div>
          </div>
          <div className="mt-2 sm:mt-0 text-sm text-gray-500">{date}</div>
        </div>

        {children}

        {showAiSuggestions && aiSuggestions && aiSuggestions.length > 0 && (
          <AISuggestion
            suggestions={aiSuggestions}
            onApplyAll={() => {
              // Implementation for applying all suggestions
            }}
          />
        )}

        {/* Action Buttons */}
        <div className="flex justify-end pt-3 border-t border-gray-200 mt-4">
          <Button
            variant="outline"
            size="sm"
            className="mr-2"
            onClick={onDelete}
          >
            <Trash2 className="w-4 h-4 mr-1" />
            Delete
          </Button>
          <Button
            variant="outline"
            size="sm"
            className="mr-2"
            onClick={onDuplicate}
          >
            <Copy className="w-4 h-4 mr-1" />
            Duplicate
          </Button>
          <Button size="sm" onClick={onSave}>
            <Save className="w-4 h-4 mr-1" />
            Save
          </Button>
        </div>
      </CardContent>
    </Card>
  );
}
