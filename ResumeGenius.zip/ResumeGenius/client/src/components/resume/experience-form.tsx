import React, { useState } from "react";
import { 
  Form,
  FormControl,
  FormField,
  FormItem,
  FormLabel,
  FormMessage
} from "@/components/ui/form";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Button } from "@/components/ui/button";
import { SectionItem } from "./section-item";
import { Switch } from "@/components/ui/switch";
import { zodResolver } from "@hookform/resolvers/zod";
import { Experience, experienceSchema } from "@shared/schema";
import { useForm } from "react-hook-form";
import { Plus, Wand2, X } from "lucide-react";
import { AISuggestion } from "./ai-suggestion";
import { KeywordBadge } from "./keyword-badge";
import { useMutation } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";

interface ExperienceFormProps {
  experience: Experience;
  isCollapsed?: boolean;
  onToggleCollapse: () => void;
  onSave: (experience: Experience) => void;
  onDuplicate: (id: string) => void;
  onDelete: (id: string) => void;
  jobDescription?: string;
}

export function ExperienceForm({
  experience,
  isCollapsed = false,
  onToggleCollapse,
  onSave,
  onDuplicate,
  onDelete,
  jobDescription
}: ExperienceFormProps) {
  const { toast } = useToast();
  const [suggestions, setSuggestions] = useState<string[]>([]);
  const [showSuggestions, setShowSuggestions] = useState(false);
  const [newAchievement, setNewAchievement] = useState("");
  const [keywords, setKeywords] = useState<{word: string, status: "matched" | "missing" | "suggested"}[]>([]);

  const form = useForm<Experience>({
    resolver: zodResolver(experienceSchema),
    defaultValues: experience
  });

  const enhanceMutation = useMutation({
    mutationFn: async () => {
      const response = await apiRequest("POST", "/api/ai/enhance", {
        sectionType: "experience",
        sectionContent: form.getValues(),
        jobDescription
      });
      return response.json();
    },
    onSuccess: (data) => {
      setSuggestions(data.suggestions || []);
      setShowSuggestions(true);
      
      // Extract keywords for the experience
      if (data.keywords) {
        setKeywords(data.keywords.map((k: any) => ({
          word: k.keyword,
          status: k.status
        })));
      }
    },
    onError: () => {
      toast({
        title: "Error",
        description: "Failed to generate AI suggestions. Please try again.",
        variant: "destructive"
      });
    }
  });

  const handleAIEnhance = () => {
    enhanceMutation.mutate();
  };

  const handleApplySuggestions = () => {
    if (enhanceMutation.data?.enhancedContent) {
      form.reset(enhanceMutation.data.enhancedContent);
      setShowSuggestions(false);
      toast({
        title: "AI suggestions applied",
        description: "Your experience has been enhanced with AI suggestions."
      });
    }
  };

  const addAchievement = () => {
    if (!newAchievement.trim()) return;
    
    const currentAchievements = form.getValues().achievements || [];
    form.setValue("achievements", [...currentAchievements, newAchievement]);
    setNewAchievement("");
  };

  const removeAchievement = (index: number) => {
    const currentAchievements = form.getValues().achievements || [];
    form.setValue(
      "achievements", 
      currentAchievements.filter((_, i) => i !== index)
    );
  };

  const handleSubmit = (values: Experience) => {
    onSave(values);
  };

  if (isCollapsed) {
    return (
      <SectionItem
        id={experience.id}
        isCollapsed={true}
        onToggleCollapse={onToggleCollapse}
        onDuplicate={() => onDuplicate(experience.id)}
        onDelete={() => onDelete(experience.id)}
        onSave={() => form.handleSubmit(handleSubmit)()}
        title={experience.position || "Position"}
        subtitle={experience.company || "Company"}
        date={experience.startDate 
          ? `${experience.startDate} - ${experience.current ? 'Present' : experience.endDate || 'End Date'}` 
          : undefined}
      />
    );
  }

  return (
    <SectionItem
      id={experience.id}
      isCollapsed={false}
      onToggleCollapse={onToggleCollapse}
      onDuplicate={() => onDuplicate(experience.id)}
      onDelete={() => onDelete(experience.id)}
      onSave={() => form.handleSubmit(handleSubmit)()}
      title={form.watch("position") || "Position"}
      subtitle={form.watch("company") || "Company"}
      date={form.watch("startDate") 
        ? `${form.watch("startDate")} - ${form.watch("current") ? 'Present' : form.watch("endDate") || 'End Date'}` 
        : undefined}
      aiSuggestions={suggestions}
      showAiSuggestions={showSuggestions}
    >
      <Form {...form}>
        <form className="space-y-4">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <FormField
              control={form.control}
              name="position"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Job Title</FormLabel>
                  <FormControl>
                    <Input placeholder="Senior Frontend Developer" {...field} value={field.value || ""} />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />

            <FormField
              control={form.control}
              name="company"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Company</FormLabel>
                  <FormControl>
                    <Input placeholder="Acme Corporation" {...field} value={field.value || ""} />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <FormField
              control={form.control}
              name="startDate"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Start Date</FormLabel>
                  <FormControl>
                    <Input placeholder="Jan 2020" {...field} value={field.value || ""} />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />

            <div className="space-y-4">
              {!form.watch("current") && (
                <FormField
                  control={form.control}
                  name="endDate"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>End Date</FormLabel>
                      <FormControl>
                        <Input placeholder="Present" {...field} value={field.value || ""} />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
              )}

              <FormField
                control={form.control}
                name="current"
                render={({ field }) => (
                  <FormItem className="flex flex-row items-center justify-between space-y-0 rounded-md border p-3">
                    <div className="space-y-0.5">
                      <FormLabel>Current Position</FormLabel>
                    </div>
                    <FormControl>
                      <Switch
                        checked={field.value}
                        onCheckedChange={field.onChange}
                      />
                    </FormControl>
                  </FormItem>
                )}
              />
            </div>
          </div>

          <FormField
            control={form.control}
            name="location"
            render={({ field }) => (
              <FormItem>
                <FormLabel>Location</FormLabel>
                <FormControl>
                  <Input placeholder="New York, NY" {...field} value={field.value || ""} />
                </FormControl>
                <FormMessage />
              </FormItem>
            )}
          />

          <div className="mb-4">
            <FormField
              control={form.control}
              name="description"
              render={({ field }) => (
                <FormItem>
                  <div className="flex items-center justify-between">
                    <FormLabel>Job Description</FormLabel>
                    <Button 
                      variant="ghost" 
                      size="sm"
                      onClick={(e) => {
                        e.preventDefault();
                        handleAIEnhance();
                      }}
                      disabled={enhanceMutation.isPending}
                    >
                      <Wand2 className="h-4 w-4 mr-1" />
                      {enhanceMutation.isPending ? "Enhancing..." : "AI Enhance"}
                    </Button>
                  </div>
                  <FormControl>
                    <Textarea 
                      placeholder="Describe your responsibilities and achievements..."
                      className="resize-none h-24"
                      {...field}
                      value={field.value || ""}
                    />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />
          </div>

          {/* Keyword Analysis */}
          {keywords.length > 0 && (
            <div className="mb-4">
              <div className="flex items-center justify-between mb-2">
                <h4 className="text-sm font-medium text-gray-700">Keyword Analysis</h4>
                <span className="text-xs text-green-500 font-medium">
                  <svg className="w-3 h-3 inline mr-1" viewBox="0 0 20 20" fill="currentColor">
                    <path fillRule="evenodd" d="M10 18a8 8 0 100-16 8 8 0 000 16zm3.707-9.293a1 1 0 00-1.414-1.414L9 10.586 7.707 9.293a1 1 0 00-1.414 1.414l2 2a1 1 0 001.414 0l4-4z" clipRule="evenodd" />
                  </svg>
                  Good Match
                </span>
              </div>
              <div className="flex flex-wrap gap-2">
                {keywords.map((keyword, index) => (
                  <KeywordBadge
                    key={index}
                    keyword={keyword.word}
                    status={keyword.status}
                    onAdd={keyword.status !== "matched" ? () => {
                      const desc = form.getValues().description || "";
                      form.setValue("description", `${desc} ${keyword.word}`);
                    } : undefined}
                  />
                ))}
              </div>
            </div>
          )}

          {/* Achievements/Bullet Points */}
          <div className="mb-4">
            <label className="block text-sm font-medium text-gray-700 mb-2">Key Achievements</label>
            <div className="space-y-2">
              {form.watch("achievements")?.map((achievement, index) => (
                <div key={index} className="flex items-start">
                  <div className="mt-1 mr-2">•</div>
                  <Input
                    value={achievement}
                    onChange={(e) => {
                      const newAchievements = [...form.getValues().achievements || []];
                      newAchievements[index] = e.target.value;
                      form.setValue("achievements", newAchievements);
                    }}
                    className="flex-1"
                  />
                  <Button
                    variant="ghost"
                    size="icon"
                    onClick={() => removeAchievement(index)}
                    className="ml-1"
                  >
                    <X className="h-4 w-4" />
                  </Button>
                </div>
              ))}
              <div className="flex items-start">
                <div className="mt-1 mr-2">•</div>
                <Input
                  placeholder="Add a new achievement..."
                  value={newAchievement}
                  onChange={(e) => setNewAchievement(e.target.value)}
                  className="flex-1"
                  onKeyDown={(e) => {
                    if (e.key === "Enter") {
                      e.preventDefault();
                      addAchievement();
                    }
                  }}
                />
                <Button
                  variant="ghost"
                  size="icon"
                  onClick={addAchievement}
                  className="ml-1"
                >
                  <Plus className="h-4 w-4" />
                </Button>
              </div>
            </div>
          </div>
        </form>
      </Form>
    </SectionItem>
  );
}
