import React, { useState, useRef } from "react";
import { Button } from "@/components/ui/button";
import { TemplateCard } from "./template-card";
import { ResumeSection } from "./resume-section";
import { ATSScore } from "./ats-score";
import { ChevronDown, Plus } from "lucide-react";
import { ResumeTemplate } from "@shared/schema";

interface ResumeSidebarProps {
  templates: ResumeTemplate[];
  selectedTemplateId: number;
  onSelectTemplate: (templateId: number) => void;
  sections: string[];
  expandedSections: string[];
  onToggleSection: (sectionId: string) => void;
  onReorderSections: (newOrder: string[]) => void;
  atsScore?: number;
  atsAnalysis?: string;
  onRunATSCheck?: () => void;
  onAddSection?: () => void;
}

export function ResumeSidebar({
  templates,
  selectedTemplateId,
  onSelectTemplate,
  sections,
  expandedSections,
  onToggleSection,
  onReorderSections,
  atsScore = 0,
  atsAnalysis = "Your resume hasn't been analyzed yet. Run an ATS check to see how your resume performs.",
  onRunATSCheck,
  onAddSection
}: ResumeSidebarProps) {
  const [isDragging, setIsDragging] = useState(false);
  const [draggedSection, setDraggedSection] = useState<string | null>(null);
  const dragOverSection = useRef<string | null>(null);

  // Handle drag events
  const handleDragStart = (e: React.DragEvent, sectionId: string) => {
    setIsDragging(true);
    setDraggedSection(sectionId);
    e.dataTransfer.setData("text/plain", sectionId);
    
    // Set custom drag image if needed
    const dragImage = document.createElement("div");
    dragImage.textContent = sectionId;
    dragImage.style.position = "absolute";
    dragImage.style.top = "-1000px";
    document.body.appendChild(dragImage);
    e.dataTransfer.setDragImage(dragImage, 0, 0);
    
    setTimeout(() => document.body.removeChild(dragImage), 0);
  };

  const handleDragOver = (e: React.DragEvent, sectionId: string) => {
    e.preventDefault();
    dragOverSection.current = sectionId;
  };

  const handleDrop = (e: React.DragEvent, targetSectionId: string) => {
    e.preventDefault();
    if (!draggedSection || draggedSection === targetSectionId) return;
    
    const sectionsCopy = [...sections];
    const draggedIndex = sectionsCopy.indexOf(draggedSection);
    const targetIndex = sectionsCopy.indexOf(targetSectionId);
    
    // Remove dragged section
    sectionsCopy.splice(draggedIndex, 1);
    
    // Insert at target position
    sectionsCopy.splice(targetIndex, 0, draggedSection);
    
    // Update sections order
    onReorderSections(sectionsCopy);
    
    // Reset dragging state
    setIsDragging(false);
    setDraggedSection(null);
    dragOverSection.current = null;
  };

  const handleDragEnd = () => {
    setIsDragging(false);
    setDraggedSection(null);
    dragOverSection.current = null;
  };

  // Helper function to get section name
  const getSectionName = (sectionId: string): { title: string, description: string } => {
    switch (sectionId) {
      case "personalInfo":
        return { title: "Personal Information", description: "Name, contact, location" };
      case "summary": 
        return { title: "Professional Summary", description: "Career highlights & goals" };
      case "experience":
        return { title: "Work Experience", description: "Jobs & responsibilities" };
      case "education":
        return { title: "Education", description: "Degrees & certifications" };
      case "skills":
        return { title: "Skills", description: "Technical & soft skills" };
      case "projects":
        return { title: "Projects", description: "Portfolio & achievements" };
      default:
        return { title: sectionId, description: "Custom section" };
    }
  };

  return (
    <div className="w-full lg:w-64 flex-shrink-0 border-r border-gray-200 bg-white">
      <div className="h-full flex flex-col">
        {/* Templates Section */}
        <div className="px-4 pt-5 pb-4 border-b border-gray-200">
          <h2 className="text-lg font-medium text-gray-900">Templates</h2>
          <div className="mt-3 flex space-x-2 overflow-x-auto pb-1">
            {templates.map((template) => (
              <TemplateCard
                key={template.id}
                template={template}
                isSelected={template.id === selectedTemplateId}
                onClick={() => onSelectTemplate(template.id)}
              />
            ))}
            <div className="template-card flex-shrink-0 w-24 h-32 rounded-md border border-dashed border-gray-300 bg-gray-50 flex flex-col items-center justify-center cursor-pointer">
              <Plus className="h-5 w-5 text-gray-400" />
              <span className="mt-1 text-xs text-gray-500">More</span>
            </div>
          </div>
        </div>

        {/* Sections */}
        <div className="flex-1 overflow-y-auto">
          <div className="px-4 py-5">
            <h2 className="text-lg font-medium text-gray-900 flex items-center justify-between">
              <span>Resume Sections</span>
              {onAddSection && (
                <button 
                  className="text-sm text-primary hover:text-primary-700"
                  onClick={onAddSection}
                >
                  <Plus className="h-4 w-4" />
                </button>
              )}
            </h2>
            <p className="mt-1 text-xs text-gray-500">Drag to reorder sections</p>

            <div className="mt-3 space-y-3">
              {sections.map((sectionId) => {
                const { title, description } = getSectionName(sectionId);
                return (
                  <div
                    key={sectionId}
                    draggable
                    onDragStart={(e) => handleDragStart(e, sectionId)}
                    onDragOver={(e) => handleDragOver(e, sectionId)}
                    onDrop={(e) => handleDrop(e, sectionId)}
                    onDragEnd={handleDragEnd}
                  >
                    <ResumeSection
                      id={sectionId}
                      title={title}
                      description={description}
                      isExpanded={expandedSections.includes(sectionId)}
                      isDragging={isDragging && draggedSection === sectionId}
                      onToggleExpand={() => onToggleSection(sectionId)}
                    >
                      {/* Section-specific content could go here if needed */}
                    </ResumeSection>
                  </div>
                );
              })}
            </div>
          </div>
        </div>

        {/* ATS Score */}
        <div className="px-4 py-4 border-t border-gray-200">
          <ATSScore
            score={atsScore}
            analysis={atsAnalysis}
            onRunFullCheck={onRunATSCheck}
          />
        </div>
      </div>
    </div>
  );
}
