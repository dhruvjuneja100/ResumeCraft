import React from "react";
import { 
  Form,
  FormControl,
  FormField,
  FormItem,
  FormLabel,
  FormMessage
} from "@/components/ui/form";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { SectionItem } from "./section-item";
import { zodResolver } from "@hookform/resolvers/zod";
import { Education, educationSchema } from "@shared/schema";
import { useForm } from "react-hook-form";

interface EducationFormProps {
  education: Education;
  isCollapsed?: boolean;
  onToggleCollapse: () => void;
  onSave: (education: Education) => void;
  onDuplicate: (id: string) => void;
  onDelete: (id: string) => void;
}

export function EducationForm({
  education,
  isCollapsed = false,
  onToggleCollapse,
  onSave,
  onDuplicate,
  onDelete
}: EducationFormProps) {
  const form = useForm<Education>({
    resolver: zodResolver(educationSchema),
    defaultValues: education
  });

  const handleSubmit = (values: Education) => {
    onSave(values);
  };

  if (isCollapsed) {
    return (
      <SectionItem
        id={education.id}
        isCollapsed={true}
        onToggleCollapse={onToggleCollapse}
        onDuplicate={() => onDuplicate(education.id)}
        onDelete={() => onDelete(education.id)}
        onSave={() => form.handleSubmit(handleSubmit)()}
        title={education.degree && education.field ? `${education.degree} in ${education.field}` : education.degree || "Degree"}
        subtitle={education.institution || "Institution"}
        date={education.startDate 
          ? `${education.startDate} - ${education.endDate || 'Present'}` 
          : undefined}
      />
    );
  }

  return (
    <SectionItem
      id={education.id}
      isCollapsed={false}
      onToggleCollapse={onToggleCollapse}
      onDuplicate={() => onDuplicate(education.id)}
      onDelete={() => onDelete(education.id)}
      onSave={() => form.handleSubmit(handleSubmit)()}
      title={form.watch("degree") && form.watch("field") 
        ? `${form.watch("degree")} in ${form.watch("field")}` 
        : form.watch("degree") || "Degree"}
      subtitle={form.watch("institution") || "Institution"}
      date={form.watch("startDate") 
        ? `${form.watch("startDate")} - ${form.watch("endDate") || 'Present'}` 
        : undefined}
    >
      <Form {...form}>
        <form className="space-y-4">
          <FormField
            control={form.control}
            name="institution"
            render={({ field }) => (
              <FormItem>
                <FormLabel>Institution</FormLabel>
                <FormControl>
                  <Input placeholder="University of Technology" {...field} value={field.value || ""} />
                </FormControl>
                <FormMessage />
              </FormItem>
            )}
          />

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <FormField
              control={form.control}
              name="degree"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Degree</FormLabel>
                  <FormControl>
                    <Input placeholder="Bachelor of Science" {...field} value={field.value || ""} />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />

            <FormField
              control={form.control}
              name="field"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Field of Study</FormLabel>
                  <FormControl>
                    <Input placeholder="Computer Science" {...field} value={field.value || ""} />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <FormField
              control={form.control}
              name="startDate"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Start Date</FormLabel>
                  <FormControl>
                    <Input placeholder="Sep 2014" {...field} value={field.value || ""} />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />

            <FormField
              control={form.control}
              name="endDate"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>End Date</FormLabel>
                  <FormControl>
                    <Input placeholder="Jun 2018" {...field} value={field.value || ""} />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />
          </div>

          <FormField
            control={form.control}
            name="location"
            render={({ field }) => (
              <FormItem>
                <FormLabel>Location</FormLabel>
                <FormControl>
                  <Input placeholder="New York, NY" {...field} value={field.value || ""} />
                </FormControl>
                <FormMessage />
              </FormItem>
            )}
          />

          <FormField
            control={form.control}
            name="gpa"
            render={({ field }) => (
              <FormItem>
                <FormLabel>GPA</FormLabel>
                <FormControl>
                  <Input placeholder="3.8/4.0" {...field} value={field.value || ""} />
                </FormControl>
                <FormMessage />
              </FormItem>
            )}
          />

          <FormField
            control={form.control}
            name="description"
            render={({ field }) => (
              <FormItem>
                <FormLabel>Description</FormLabel>
                <FormControl>
                  <Textarea 
                    placeholder="Relevant coursework, achievements, or activities..."
                    className="resize-none h-24"
                    {...field}
                    value={field.value || ""}
                  />
                </FormControl>
                <FormMessage />
              </FormItem>
            )}
          />
        </form>
      </Form>
    </SectionItem>
  );
}
