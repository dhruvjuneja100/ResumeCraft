import React from "react";
import { cn } from "@/lib/utils";
import { ResumeContent } from "@shared/schema";

interface ResumeTemplateProps {
  content: ResumeContent;
  templateStyle?: {
    colors: {
      primary: string;
      secondary: string;
    };
    layout: "standard" | "sidebar" | "centered";
    fonts: {
      title: string;
      body: string;
    };
  };
  className?: string;
}

export function ResumeTemplate({
  content,
  templateStyle = {
    colors: { primary: "#2563eb", secondary: "#e5e7eb" },
    layout: "standard",
    fonts: { title: "Inter", body: "Inter" },
  },
  className,
}: ResumeTemplateProps) {
  // Helper function to render experience items
  const renderExperience = () => {
    return content.experience.map((exp) => (
      <div key={exp.id} className="mb-4">
        <div className="flex justify-between items-start">
          <div>
            <h3 className="text-base font-medium text-gray-900">
              {exp.position || "Position"}
            </h3>
            <p className="text-sm text-gray-600">{exp.company || "Company"}</p>
          </div>
          <p className="text-sm text-gray-500">
            {exp.startDate || "Start Date"} -{" "}
            {exp.current ? "Present" : exp.endDate || "End Date"}
          </p>
        </div>
        {exp.description && (
          <p className="mt-2 text-sm text-gray-700">{exp.description}</p>
        )}
        {exp.achievements.length > 0 && (
          <ul className="mt-2 list-disc pl-5 text-sm text-gray-700 space-y-1">
            {exp.achievements.map((achievement, index) => (
              <li key={index}>{achievement}</li>
            ))}
          </ul>
        )}
      </div>
    ));
  };

  // Helper function to render education items
  const renderEducation = () => {
    return content.education.map((edu) => (
      <div key={edu.id} className="mb-4">
        <div className="flex justify-between items-start">
          <div>
            <h3 className="text-base font-medium text-gray-900">
              {edu.degree || "Degree"} {edu.field && `in ${edu.field}`}
            </h3>
            <p className="text-sm text-gray-600">
              {edu.institution || "Institution"}
            </p>
          </div>
          <p className="text-sm text-gray-500">
            {edu.startDate || "Start Date"} -{" "}
            {edu.endDate || "End Date"}
          </p>
        </div>
        {edu.description && (
          <p className="mt-2 text-sm text-gray-700">{edu.description}</p>
        )}
      </div>
    ));
  };

  // Helper function to render skills
  const renderSkills = () => {
    return (
      <div className="flex flex-wrap gap-2">
        {content.skills.map((skill) => (
          <span
            key={skill.id}
            className="px-2 py-1 bg-gray-100 text-gray-800 text-sm rounded"
          >
            {skill.name}
          </span>
        ))}
      </div>
    );
  };

  // Helper function to render projects
  const renderProjects = () => {
    return content.projects.map((project) => (
      <div key={project.id} className="mb-4">
        <div className="flex justify-between items-start">
          <div>
            <h3 className="text-base font-medium text-gray-900">
              {project.name || "Project Name"}
            </h3>
            {project.url && (
              <a
                href={project.url}
                target="_blank"
                rel="noopener noreferrer"
                className="text-sm text-primary hover:underline"
              >
                {project.url}
              </a>
            )}
          </div>
          {(project.startDate || project.endDate) && (
            <p className="text-sm text-gray-500">
              {project.startDate} - {project.endDate}
            </p>
          )}
        </div>
        {project.description && (
          <p className="mt-2 text-sm text-gray-700">{project.description}</p>
        )}
        {project.highlights.length > 0 && (
          <ul className="mt-2 list-disc pl-5 text-sm text-gray-700 space-y-1">
            {project.highlights.map((highlight, index) => (
              <li key={index}>{highlight}</li>
            ))}
          </ul>
        )}
      </div>
    ));
  };

  const renderSectionContent = (sectionName: string) => {
    switch (sectionName) {
      case "experience":
        return (
          <div className="mb-6">
            <h2
              className="text-lg font-semibold text-gray-800 border-b border-gray-300 pb-1 mb-3"
              style={{ color: templateStyle.colors.primary }}
            >
              Work Experience
            </h2>
            {renderExperience()}
          </div>
        );
      case "education":
        return (
          <div className="mb-6">
            <h2
              className="text-lg font-semibold text-gray-800 border-b border-gray-300 pb-1 mb-3"
              style={{ color: templateStyle.colors.primary }}
            >
              Education
            </h2>
            {renderEducation()}
          </div>
        );
      case "skills":
        return (
          <div className="mb-6">
            <h2
              className="text-lg font-semibold text-gray-800 border-b border-gray-300 pb-1 mb-3"
              style={{ color: templateStyle.colors.primary }}
            >
              Skills
            </h2>
            {renderSkills()}
          </div>
        );
      case "projects":
        return (
          <div className="mb-6">
            <h2
              className="text-lg font-semibold text-gray-800 border-b border-gray-300 pb-1 mb-3"
              style={{ color: templateStyle.colors.primary }}
            >
              Projects
            </h2>
            {renderProjects()}
          </div>
        );
      case "summary":
        return (
          <div className="mb-6">
            <h2
              className="text-lg font-semibold text-gray-800 border-b border-gray-300 pb-1 mb-2"
              style={{ color: templateStyle.colors.primary }}
            >
              Professional Summary
            </h2>
            <p className="text-sm text-gray-700">{content.summary}</p>
          </div>
        );
      default:
        return null;
    }
  };

  // Render personal info
  const renderPersonalInfo = () => {
    const { personalInfo } = content;
    return (
      <div className="text-center mb-6">
        <h1 className="text-2xl font-bold text-gray-900">
          {personalInfo.fullName || "Your Name"}
        </h1>
        <p className="text-gray-600">{personalInfo.headline || "Your Title"}</p>
        <div className="flex justify-center items-center space-x-3 mt-2 text-sm text-gray-500">
          {personalInfo.email && (
            <span>
              <svg
                className="w-4 h-4 inline mr-1"
                fill="currentColor"
                viewBox="0 0 20 20"
              >
                <path d="M2.003 5.884L10 9.882l7.997-3.998A2 2 0 0016 4H4a2 2 0 00-1.997 1.884z" />
                <path d="M18 8.118l-8 4-8-4V14a2 2 0 002 2h12a2 2 0 002-2V8.118z" />
              </svg>
              {personalInfo.email}
            </span>
          )}
          {personalInfo.phone && (
            <span>
              <svg
                className="w-4 h-4 inline mr-1"
                fill="currentColor"
                viewBox="0 0 20 20"
              >
                <path d="M2 3a1 1 0 011-1h2.153a1 1 0 01.986.836l.74 4.435a1 1 0 01-.54 1.06l-1.548.773a11.037 11.037 0 006.105 6.105l.774-1.548a1 1 0 011.059-.54l4.435.74a1 1 0 01.836.986V17a1 1 0 01-1 1h-2C7.82 18 2 12.18 2 5V3z" />
              </svg>
              {personalInfo.phone}
            </span>
          )}
          {personalInfo.location && (
            <span>
              <svg
                className="w-4 h-4 inline mr-1"
                fill="currentColor"
                viewBox="0 0 20 20"
              >
                <path
                  fillRule="evenodd"
                  d="M5.05 4.05a7 7 0 119.9 9.9L10 18.9l-4.95-4.95a7 7 0 010-9.9zM10 11a2 2 0 100-4 2 2 0 000 4z"
                  clipRule="evenodd"
                />
              </svg>
              {personalInfo.location}
            </span>
          )}
        </div>
      </div>
    );
  };

  return (
    <div
      className={cn(
        "bg-white border border-gray-200 shadow-sm w-full mx-auto",
        className
      )}
      style={{
        maxWidth: "8.5in",
        minHeight: "11in",
        fontFamily: templateStyle.fonts.body,
      }}
    >
      <div className="p-8">
        {/* Header with personal info */}
        {renderPersonalInfo()}

        {/* Resume sections */}
        {content.sections
          .filter((section) => section !== "personalInfo")
          .map((sectionName) => (
            <div key={sectionName}>
              {renderSectionContent(sectionName)}
            </div>
          ))}
      </div>
    </div>
  );
}
