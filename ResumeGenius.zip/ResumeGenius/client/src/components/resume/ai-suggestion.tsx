import React from "react";
import { Button } from "@/components/ui/button";
import { Wand2 } from "lucide-react";
import { cn } from "@/lib/utils";

interface AISuggestionProps {
  suggestions: string[];
  onApplyAll: () => void;
  onCustomize?: () => void;
  className?: string;
}

export function AISuggestion({
  suggestions,
  onApplyAll,
  onCustomize,
  className,
}: AISuggestionProps) {
  return (
    <div
      className={cn(
        "p-3 bg-purple-50 border border-purple-200 rounded-md mb-4",
        className
      )}
    >
      <div className="flex items-start">
        <div className="flex-shrink-0 mt-0.5 text-purple-600">
          <svg
            className="h-5 w-5"
            fill="currentColor"
            viewBox="0 0 20 20"
            xmlns="http://www.w3.org/2000/svg"
          >
            <path
              fillRule="evenodd"
              d="M14.243 5.757a6 6 0 10-.986 9.284 1 1 0 111.087 1.678A8 8 0 1118 10a3 3 0 01-4.8 2.401A4 4 0 1114 10a1 1 0 102 0c0-1.537-.586-3.07-1.757-4.243zM12 10a2 2 0 10-4 0 2 2 0 004 0z"
              clipRule="evenodd"
            ></path>
          </svg>
        </div>
        <div className="ml-3">
          <h4 className="text-sm font-medium text-purple-800">
            AI Enhancement Suggestions
          </h4>
          <div className="mt-2 text-sm text-purple-700">
            <p className="mb-2">
              Consider adding these details to strengthen your experience:
            </p>
            <ul className="list-disc pl-5 space-y-1">
              {suggestions.map((suggestion, index) => (
                <li key={index}>{suggestion}</li>
              ))}
            </ul>
          </div>
          <div className="mt-2 flex">
            <Button
              size="sm"
              variant="outline"
              className="mr-2 text-xs bg-purple-100 hover:bg-purple-200 text-purple-800 border-purple-200"
              onClick={onApplyAll}
            >
              <Wand2 className="h-3 w-3 mr-1" />
              Apply All
            </Button>
            {onCustomize && (
              <Button
                size="sm"
                variant="link"
                className="text-xs text-purple-600 hover:text-purple-800"
                onClick={onCustomize}
              >
                Customize
              </Button>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}
