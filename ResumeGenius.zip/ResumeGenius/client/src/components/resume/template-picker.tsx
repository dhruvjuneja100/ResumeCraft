import React from "react";
import { Card, CardContent } from "@/components/ui/card";
import { ResumeTemplate } from "@shared/schema";
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group";
import { Label } from "@/components/ui/label";

interface TemplatePickerProps {
  templates: ResumeTemplate[];
  selectedTemplateId: number;
  onSelectTemplate: (templateId: number) => void;
}

export function TemplatePicker({
  templates,
  selectedTemplateId,
  onSelectTemplate,
}: TemplatePickerProps) {
  return (
    <Card className="mb-6">
      <CardContent className="pt-6">
        <h2 className="text-lg font-medium text-gray-900 mb-4">Choose a Template</h2>
        
        <RadioGroup
          value={selectedTemplateId.toString()}
          onValueChange={(value) => onSelectTemplate(parseInt(value))}
          className="grid grid-cols-1 md:grid-cols-3 gap-4"
        >
          {templates.map((template) => (
            <div key={template.id} className="relative">
              <RadioGroupItem
                value={template.id.toString()}
                id={`template-${template.id}`}
                className="sr-only"
              />
              <Label
                htmlFor={`template-${template.id}`}
                className="cursor-pointer block"
              >
                <div className={`relative rounded-md overflow-hidden border-2 transition-all ${
                  selectedTemplateId === template.id 
                    ? 'border-primary shadow-md' 
                    : 'border-gray-200 hover:border-gray-300'
                }`}>
                  <div className="h-40 bg-gray-100 flex items-center justify-center">
                    <svg
                      className="w-full h-full text-gray-200"
                      viewBox="0 0 200 150"
                      fill="none"
                      xmlns="http://www.w3.org/2000/svg"
                    >
                      {/* Template preview based on structure */}
                      {template.structure.layout === "standard" && (
                        <>
                          <rect x="20" y="10" width="160" height="20" rx="2" fill={`${template.structure.colors.primary}`} />
                          <rect x="20" y="35" width="160" height="5" rx="1" fill="#e5e7eb" />
                          <rect x="20" y="45" width="160" height="5" rx="1" fill="#e5e7eb" />
                          <rect x="20" y="55" width="160" height="5" rx="1" fill="#e5e7eb" />
                          <rect x="20" y="70" width="160" height="10" rx="2" fill={`${template.structure.colors.secondary}`} />
                          <rect x="20" y="85" width="160" height="5" rx="1" fill="#e5e7eb" />
                          <rect x="20" y="95" width="160" height="5" rx="1" fill="#e5e7eb" />
                          <rect x="20" y="110" width="160" height="10" rx="2" fill={`${template.structure.colors.secondary}`} />
                          <rect x="20" y="125" width="160" height="5" rx="1" fill="#e5e7eb" />
                          <rect x="20" y="135" width="160" height="5" rx="1" fill="#e5e7eb" />
                        </>
                      )}
                      {template.structure.layout === "sidebar" && (
                        <>
                          <rect x="20" y="10" width="40" height="130" rx="2" fill={`${template.structure.colors.primary}`} />
                          <rect x="70" y="10" width="110" height="15" rx="2" fill={`${template.structure.colors.secondary}`} />
                          <rect x="70" y="30" width="110" height="5" rx="1" fill="#e5e7eb" />
                          <rect x="70" y="40" width="110" height="5" rx="1" fill="#e5e7eb" />
                          <rect x="70" y="50" width="110" height="5" rx="1" fill="#e5e7eb" />
                          <rect x="70" y="65" width="110" height="10" rx="2" fill={`${template.structure.colors.secondary}`} />
                          <rect x="70" y="80" width="110" height="5" rx="1" fill="#e5e7eb" />
                          <rect x="70" y="90" width="110" height="5" rx="1" fill="#e5e7eb" />
                          <rect x="70" y="105" width="110" height="10" rx="2" fill={`${template.structure.colors.secondary}`} />
                          <rect x="70" y="120" width="110" height="5" rx="1" fill="#e5e7eb" />
                          <rect x="70" y="130" width="110" height="5" rx="1" fill="#e5e7eb" />
                        </>
                      )}
                      {template.structure.layout === "centered" && (
                        <>
                          <rect x="50" y="10" width="100" height="20" rx="2" fill={`${template.structure.colors.primary}`} />
                          <rect x="60" y="35" width="80" height="5" rx="1" fill="#e5e7eb" />
                          <rect x="50" y="45" width="100" height="5" rx="1" fill="#e5e7eb" />
                          <rect x="40" y="55" width="120" height="5" rx="1" fill="#e5e7eb" />
                          <rect x="50" y="70" width="100" height="10" rx="2" fill={`${template.structure.colors.secondary}`} />
                          <rect x="50" y="85" width="100" height="5" rx="1" fill="#e5e7eb" />
                          <rect x="50" y="95" width="100" height="5" rx="1" fill="#e5e7eb" />
                          <rect x="50" y="110" width="100" height="10" rx="2" fill={`${template.structure.colors.secondary}`} />
                          <rect x="50" y="125" width="100" height="5" rx="1" fill="#e5e7eb" />
                          <rect x="50" y="135" width="100" height="5" rx="1" fill="#e5e7eb" />
                        </>
                      )}
                    </svg>
                  </div>
                  <div className="p-3 bg-white">
                    <h3 className="font-medium">{template.name}</h3>
                    <p className="text-xs text-gray-500 mt-1">{template.description}</p>
                  </div>
                  
                  {selectedTemplateId === template.id && (
                    <div className="absolute top-2 right-2 h-6 w-6 bg-primary text-white rounded-full flex items-center justify-center">
                      <svg width="12" height="12" viewBox="0 0 12 12" fill="none" xmlns="http://www.w3.org/2000/svg">
                        <path d="M10 3L4.5 8.5L2 6" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
                      </svg>
                    </div>
                  )}
                </div>
              </Label>
            </div>
          ))}
        </RadioGroup>
      </CardContent>
    </Card>
  );
}
