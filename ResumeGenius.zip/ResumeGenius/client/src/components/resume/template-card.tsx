import React from "react";
import { cn } from "@/lib/utils";
import { ResumeTemplate } from "@shared/schema";

interface TemplateCardProps {
  template: ResumeTemplate;
  isSelected: boolean;
  onClick: () => void;
  className?: string;
}

export function TemplateCard({
  template,
  isSelected,
  onClick,
  className,
}: TemplateCardProps) {
  return (
    <div
      className={cn(
        "flex-shrink-0 w-24 h-32 rounded-md border bg-white flex items-center justify-center cursor-pointer overflow-hidden transition-all hover:shadow-md hover:-translate-y-1",
        isSelected ? "border-2 border-primary" : "border-gray-300",
        className
      )}
      onClick={onClick}
    >
      <div className="relative w-full h-full">
        <div className="absolute inset-0 flex items-center justify-center">
          {/* Use SVG representation of template */}
          <svg
            className="w-full h-full text-gray-200"
            viewBox="0 0 100 140"
            fill="none"
            xmlns="http://www.w3.org/2000/svg"
          >
            {/* Template preview based on structure */}
            {template.structure.layout === "standard" && (
              <>
                <rect x="10" y="10" width="80" height="15" rx="2" fill={`${template.structure.colors.primary}`} />
                <rect x="10" y="30" width="80" height="5" rx="1" fill="#e5e7eb" />
                <rect x="10" y="40" width="80" height="5" rx="1" fill="#e5e7eb" />
                <rect x="10" y="50" width="80" height="5" rx="1" fill="#e5e7eb" />
                <rect x="10" y="65" width="80" height="10" rx="2" fill={`${template.structure.colors.secondary}`} />
                <rect x="10" y="80" width="80" height="5" rx="1" fill="#e5e7eb" />
                <rect x="10" y="90" width="80" height="5" rx="1" fill="#e5e7eb" />
                <rect x="10" y="105" width="80" height="10" rx="2" fill={`${template.structure.colors.secondary}`} />
                <rect x="10" y="120" width="80" height="5" rx="1" fill="#e5e7eb" />
              </>
            )}
            {template.structure.layout === "sidebar" && (
              <>
                <rect x="10" y="10" width="25" height="120" rx="2" fill={`${template.structure.colors.primary}`} />
                <rect x="40" y="10" width="50" height="10" rx="2" fill={`${template.structure.colors.secondary}`} />
                <rect x="40" y="25" width="50" height="5" rx="1" fill="#e5e7eb" />
                <rect x="40" y="35" width="50" height="5" rx="1" fill="#e5e7eb" />
                <rect x="40" y="50" width="50" height="10" rx="2" fill={`${template.structure.colors.secondary}`} />
                <rect x="40" y="65" width="50" height="5" rx="1" fill="#e5e7eb" />
                <rect x="40" y="75" width="50" height="5" rx="1" fill="#e5e7eb" />
                <rect x="40" y="90" width="50" height="10" rx="2" fill={`${template.structure.colors.secondary}`} />
                <rect x="40" y="105" width="50" height="5" rx="1" fill="#e5e7eb" />
                <rect x="40" y="115" width="50" height="5" rx="1" fill="#e5e7eb" />
              </>
            )}
            {template.structure.layout === "centered" && (
              <>
                <rect x="20" y="10" width="60" height="15" rx="2" fill={`${template.structure.colors.primary}`} />
                <rect x="30" y="30" width="40" height="5" rx="1" fill="#e5e7eb" />
                <rect x="25" y="40" width="50" height="5" rx="1" fill="#e5e7eb" />
                <rect x="20" y="55" width="60" height="10" rx="2" fill={`${template.structure.colors.secondary}`} />
                <rect x="20" y="70" width="60" height="5" rx="1" fill="#e5e7eb" />
                <rect x="20" y="80" width="60" height="5" rx="1" fill="#e5e7eb" />
                <rect x="20" y="95" width="60" height="10" rx="2" fill={`${template.structure.colors.secondary}`} />
                <rect x="20" y="110" width="60" height="5" rx="1" fill="#e5e7eb" />
                <rect x="20" y="120" width="60" height="5" rx="1" fill="#e5e7eb" />
              </>
            )}
          </svg>
        </div>
        <div className="absolute bottom-0 left-0 right-0 bg-white bg-opacity-90 text-center py-1 text-xs font-medium text-gray-800">
          {template.name}
        </div>
      </div>
    </div>
  );
}
