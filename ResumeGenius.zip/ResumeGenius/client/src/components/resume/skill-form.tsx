import React, { useState } from 'react';
import { Skill } from '@shared/schema';
import { Button } from '@/components/ui/button';
import { Card } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Badge } from '@/components/ui/badge';
import { X, Plus } from 'lucide-react';
import { v4 as uuidv4 } from 'uuid';

interface SkillFormProps {
  skills: Skill[];
  onAdd: (skill: Skill) => void;
  onUpdate: (id: string, skill: Skill) => void;
  onDelete: (id: string) => void;
}

export function SkillForm({ skills, onAdd, onUpdate, onDelete }: SkillFormProps) {
  const [newSkill, setNewSkill] = useState<Skill>({
    id: '',
    name: '',
    level: 'Intermediate',
    category: 'Technical'
  });

  const skillLevels = ['Beginner', 'Intermediate', 'Advanced', 'Expert'];
  const skillCategories = ['Technical', 'Soft', 'Language', 'Tool', 'Framework', 'Other'];

  const handleAddSkill = () => {
    if (newSkill.name.trim() === '') return;
    
    onAdd({
      ...newSkill,
      id: uuidv4()
    });
    
    setNewSkill({
      id: '',
      name: '',
      level: 'Intermediate',
      category: 'Technical'
    });
  };

  const handleKeyDown = (e: React.KeyboardEvent) => {
    if (e.key === 'Enter') {
      e.preventDefault();
      handleAddSkill();
    }
  };

  return (
    <Card className="p-6 shadow-sm">
      <div className="space-y-6">
        <div>
          <Label className="text-lg font-medium">Your Skills</Label>
          <p className="text-sm text-gray-500 mt-1">
            Add relevant skills to showcase your expertise. Include both technical and soft skills.
          </p>
        </div>

        <div className="flex flex-col sm:flex-row gap-3">
          <div className="flex-1">
            <Label htmlFor="skill-name">Skill Name</Label>
            <Input
              id="skill-name"
              value={newSkill.name}
              onChange={(e) => setNewSkill({ ...newSkill, name: e.target.value })}
              placeholder="Enter a skill (e.g., JavaScript, Project Management)"
              onKeyDown={handleKeyDown}
            />
          </div>
          
          <div className="w-full sm:w-[180px]">
            <Label htmlFor="skill-level">Level</Label>
            <Select
              value={newSkill.level}
              onValueChange={(value) => setNewSkill({ ...newSkill, level: value })}
            >
              <SelectTrigger id="skill-level">
                <SelectValue placeholder="Select level" />
              </SelectTrigger>
              <SelectContent>
                {skillLevels.map((level) => (
                  <SelectItem key={level} value={level}>
                    {level}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>
          
          <div className="w-full sm:w-[180px]">
            <Label htmlFor="skill-category">Category</Label>
            <Select
              value={newSkill.category}
              onValueChange={(value) => setNewSkill({ ...newSkill, category: value })}
            >
              <SelectTrigger id="skill-category">
                <SelectValue placeholder="Select category" />
              </SelectTrigger>
              <SelectContent>
                {skillCategories.map((category) => (
                  <SelectItem key={category} value={category}>
                    {category}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>
          
          <div className="flex items-end">
            <Button 
              onClick={handleAddSkill}
              disabled={!newSkill.name.trim()}
              className="w-full sm:w-auto"
            >
              <Plus className="w-4 h-4 mr-2" />
              Add
            </Button>
          </div>
        </div>

        {skills.length > 0 && (
          <div className="mt-6">
            <h3 className="text-sm font-medium text-gray-700 mb-3">Your Skills</h3>
            <div className="flex flex-wrap gap-2">
              {skills.map((skill) => (
                <Badge
                  key={skill.id}
                  variant="secondary"
                  className="px-3 py-1.5 gap-2 text-sm group hover:bg-gray-100"
                >
                  <span className="font-medium">{skill.name}</span>
                  <span className="text-xs text-gray-500">({skill.level})</span>
                  <button
                    type="button"
                    onClick={() => onDelete(skill.id)}
                    className="ml-1 text-gray-400 hover:text-red-500 focus:outline-none"
                    aria-label={`Remove ${skill.name} skill`}
                  >
                    <X className="w-3.5 h-3.5" />
                  </button>
                </Badge>
              ))}
            </div>
          </div>
        )}

        {/* Skill categories */}
        {skills.length > 0 && (
          <div className="mt-6 space-y-4">
            {Array.from(new Set(skills.map(s => s.category))).map(category => (
              <div key={category} className="border-t pt-4">
                <h3 className="text-sm font-medium text-gray-700 mb-2">{category}</h3>
                <div className="flex flex-wrap gap-2">
                  {skills.filter(s => s.category === category).map(skill => (
                    <Badge
                      key={skill.id}
                      variant="outline"
                      className="px-2 py-1 text-sm"
                    >
                      {skill.name}
                    </Badge>
                  ))}
                </div>
              </div>
            ))}
          </div>
        )}
      </div>
    </Card>
  );
}