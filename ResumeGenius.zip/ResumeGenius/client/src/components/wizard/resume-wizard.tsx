import React, { useState } from 'react';
import { Steps, useSteps } from 'react-step-builder';
import styled from 'styled-components';
import { Card } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { 
  FileText, User, Briefcase, GraduationCap, 
  Award, Code, ArrowLeft, ArrowRight, Check 
} from 'lucide-react';
import { ResumeContent } from '@shared/schema';
import { useResume } from '@/hooks/use-resume';
import { PersonalInfoForm } from '@/components/resume/personal-info-form';
import { SummaryForm } from '@/components/resume/summary-form';
import { ExperienceForm } from '@/components/resume/experience-form';
import { EducationForm } from '@/components/resume/education-form';
import { SkillForm } from '@/components/resume/skill-form';
import { ResumeTemplate } from '@/components/resume/resume-template';
import { TemplatePicker } from '@/components/resume/template-picker';
import { useToast } from '@/hooks/use-toast';
import { useQuery } from '@tanstack/react-query';
import { useLocation } from 'wouter';
import type { ResumeTemplate as ResumeTemplateType } from '@shared/schema';

// Styled Components
const WizardContainer = styled.div`
  max-width: 1200px;
  margin: 0 auto;
  padding: 2rem;
`;

const StepIndicator = styled.div`
  display: flex;
  justify-content: space-between;
  margin-bottom: 2rem;
  position: relative;
  
  &::before {
    content: "";
    position: absolute;
    top: 50%;
    left: 0;
    right: 0;
    height: 2px;
    background: #e5e7eb;
    z-index: 0;
    transform: translateY(-50%);
  }
`;

const StepItem = styled.div<{ active: boolean; completed: boolean }>`
  display: flex;
  flex-direction: column;
  align-items: center;
  position: relative;
  z-index: 1;
  
  .step-number {
    width: 40px;
    height: 40px;
    border-radius: 50%;
    background: ${props => props.active ? 'var(--primary)' : props.completed ? '#10b981' : '#fff'};
    color: ${props => props.active || props.completed ? '#fff' : '#6b7280'};
    border: 2px solid ${props => props.active ? 'var(--primary)' : props.completed ? '#10b981' : '#e5e7eb'};
    display: flex;
    align-items: center;
    justify-content: center;
    font-weight: 600;
    margin-bottom: 0.5rem;
  }
  
  .step-label {
    font-size: 0.875rem;
    color: ${props => props.active ? 'var(--primary)' : props.completed ? '#10b981' : '#6b7280'};
    font-weight: ${props => props.active ? '600' : '500'};
  }
`;

const StepContent = styled.div`
  margin-bottom: 2rem;
`;

const Navigation = styled.div`
  display: flex;
  justify-content: space-between;
  margin-top: 2rem;
`;

const ContentContainer = styled.div`
  display: grid;
  grid-template-columns: 1fr 1fr;
  gap: 2rem;
  
  @media (max-width: 768px) {
    grid-template-columns: 1fr;
  }
`;

// Step components
const PersonalInfoStep = ({ next, userData }: any) => {
  const { resumeContent, updatePersonalInfo } = useResume();
  
  const handleSubmit = (values: any) => {
    updatePersonalInfo(values);
    next();
  };
  
  return (
    <>
      <h2 className="text-2xl font-bold mb-4">Personal Information</h2>
      <p className="text-gray-600 mb-6">
        Let's start with your basic information that will appear at the top of your resume.
      </p>
      <ContentContainer>
        <div>
          <PersonalInfoForm
            personalInfo={resumeContent.personalInfo}
            onUpdate={handleSubmit}
          />
        </div>
        <div>
          <Card className="p-6 shadow-md">
            <h3 className="text-lg font-semibold mb-4">Tips:</h3>
            <ul className="list-disc list-inside space-y-2 text-gray-700">
              <li>Use a professional email address</li>
              <li>Include your LinkedIn profile URL if available</li>
              <li>Add a personal website or portfolio if relevant</li>
              <li>Your location should include city and state/country</li>
              <li>A headline helps summarize your professional identity in a few words</li>
            </ul>
          </Card>
        </div>
      </ContentContainer>
    </>
  );
};

const TemplateStep = ({ next, prev }: any) => {
  const { data: templates = [] } = useQuery<ResumeTemplateType[]>({
    queryKey: ["/api/templates"],
  });
  const [selectedTemplateId, setSelectedTemplateId] = useState<number>(1);
  const { resumeContent } = useResume();
  
  const selectedTemplate = templates.find(t => t.id === selectedTemplateId) || templates[0];
  
  const handleNext = () => {
    // Save template selection
    next();
  };
  
  return (
    <>
      <h2 className="text-2xl font-bold mb-4">Choose Your Template</h2>
      <p className="text-gray-600 mb-6">
        Select a template that best represents your professional style.
      </p>
      <ContentContainer>
        <div>
          <TemplatePicker
            templates={templates}
            selectedTemplateId={selectedTemplateId}
            onSelectTemplate={setSelectedTemplateId}
          />
        </div>
        <div>
          <Card className="p-6 shadow-md h-full overflow-auto">
            <h3 className="text-lg font-semibold mb-4">Preview</h3>
            <div className="transform scale-75 origin-top">
              <ResumeTemplate
                content={resumeContent}
                templateStyle={
                  selectedTemplate?.structure 
                    ? selectedTemplate.structure as any 
                    : {
                        colors: { primary: "#2563eb", secondary: "#e5e7eb" },
                        layout: "standard",
                        fonts: { title: "Inter", body: "Inter" }
                      }
                }
              />
            </div>
          </Card>
        </div>
      </ContentContainer>
      <Navigation>
        <Button variant="outline" onClick={prev}>
          <ArrowLeft className="w-4 h-4 mr-2" /> Back
        </Button>
        <Button onClick={handleNext}>
          Next <ArrowRight className="w-4 h-4 ml-2" />
        </Button>
      </Navigation>
    </>
  );
};

const SummaryStep = ({ next, prev }: any) => {
  const { resumeContent, updateSummary } = useResume();
  
  const handleSubmit = (summary: string) => {
    updateSummary(summary);
    next();
  };
  
  return (
    <>
      <h2 className="text-2xl font-bold mb-4">Professional Summary</h2>
      <p className="text-gray-600 mb-6">
        Add a compelling summary that highlights your experience, skills, and career goals.
      </p>
      <ContentContainer>
        <div>
          <SummaryForm
            summary={resumeContent.summary}
            onUpdate={handleSubmit}
          />
        </div>
        <div>
          <Card className="p-6 shadow-md">
            <h3 className="text-lg font-semibold mb-4">Tips:</h3>
            <ul className="list-disc list-inside space-y-2 text-gray-700">
              <li>Keep your summary concise (3-5 sentences)</li>
              <li>Highlight your years of experience and key achievements</li>
              <li>Mention your most valuable skills and expertise</li>
              <li>Tailor your summary to match the job descriptions you're targeting</li>
              <li>Avoid generic statements; use specific accomplishments instead</li>
            </ul>
          </Card>
        </div>
      </ContentContainer>
      <Navigation>
        <Button variant="outline" onClick={prev}>
          <ArrowLeft className="w-4 h-4 mr-2" /> Back
        </Button>
        <Button onClick={() => handleSubmit(resumeContent.summary)}>
          Next <ArrowRight className="w-4 h-4 ml-2" />
        </Button>
      </Navigation>
    </>
  );
};

const ExperienceStep = ({ next, prev }: any) => {
  const { resumeContent, addExperience, updateExperience, removeExperience } = useResume();
  
  return (
    <>
      <h2 className="text-2xl font-bold mb-4">Work Experience</h2>
      <p className="text-gray-600 mb-6">
        Add your work experience, starting with the most recent position.
      </p>
      <ContentContainer>
        <div className="space-y-6">
          {resumeContent.experience.length === 0 ? (
            <div className="text-center p-8 border border-dashed border-gray-300 rounded-md">
              <Briefcase className="w-12 h-12 mx-auto text-gray-400 mb-3" />
              <h3 className="text-lg font-medium text-gray-700 mb-2">No experience added yet</h3>
              <p className="text-gray-500 mb-4">
                Add your work experience to make your resume stand out.
              </p>
              <Button onClick={() => addExperience()}>
                Add Experience
              </Button>
            </div>
          ) : (
            <>
              {resumeContent.experience.map((exp) => (
                <ExperienceForm
                  key={exp.id}
                  experience={exp}
                  onToggleCollapse={() => {}}
                  onSave={(updatedExp) => updateExperience(exp.id, updatedExp)}
                  onDuplicate={() => {}}
                  onDelete={(id) => removeExperience(id)}
                />
              ))}
              <Button 
                className="mt-4"
                variant="outline"
                onClick={() => addExperience()}
              >
                Add Another Position
              </Button>
            </>
          )}
        </div>
        <div>
          <Card className="p-6 shadow-md">
            <h3 className="text-lg font-semibold mb-4">Tips:</h3>
            <ul className="list-disc list-inside space-y-2 text-gray-700">
              <li>List your experiences in reverse chronological order</li>
              <li>Use action verbs to describe your responsibilities</li>
              <li>Quantify your achievements with numbers when possible</li>
              <li>Focus on achievements rather than just duties</li>
              <li>Include relevant experiences even if they're not directly related to your target job</li>
            </ul>
          </Card>
        </div>
      </ContentContainer>
      <Navigation>
        <Button variant="outline" onClick={prev}>
          <ArrowLeft className="w-4 h-4 mr-2" /> Back
        </Button>
        <Button onClick={next}>
          Next <ArrowRight className="w-4 h-4 ml-2" />
        </Button>
      </Navigation>
    </>
  );
};

const EducationStep = ({ next, prev }: any) => {
  const { resumeContent, addEducation, updateEducation, removeEducation } = useResume();
  
  return (
    <>
      <h2 className="text-2xl font-bold mb-4">Education</h2>
      <p className="text-gray-600 mb-6">
        Add your educational background, starting with the highest degree earned.
      </p>
      <ContentContainer>
        <div className="space-y-6">
          {resumeContent.education.length === 0 ? (
            <div className="text-center p-8 border border-dashed border-gray-300 rounded-md">
              <GraduationCap className="w-12 h-12 mx-auto text-gray-400 mb-3" />
              <h3 className="text-lg font-medium text-gray-700 mb-2">No education added yet</h3>
              <p className="text-gray-500 mb-4">
                Add your educational background to strengthen your resume.
              </p>
              <Button onClick={() => addEducation()}>
                Add Education
              </Button>
            </div>
          ) : (
            <>
              {resumeContent.education.map((edu) => (
                <EducationForm
                  key={edu.id}
                  education={edu}
                  onToggleCollapse={() => {}}
                  onSave={(updatedEdu) => updateEducation(edu.id, updatedEdu)}
                  onDuplicate={() => {}}
                  onDelete={(id) => removeEducation(id)}
                />
              ))}
              <Button 
                className="mt-4"
                variant="outline"
                onClick={() => addEducation()}
              >
                Add Another Education
              </Button>
            </>
          )}
        </div>
        <div>
          <Card className="p-6 shadow-md">
            <h3 className="text-lg font-semibold mb-4">Tips:</h3>
            <ul className="list-disc list-inside space-y-2 text-gray-700">
              <li>Include your highest level of education first</li>
              <li>Add relevant courses, honors, and academic achievements</li>
              <li>If you're a recent graduate, include your GPA if it's 3.5 or higher</li>
              <li>For professionals with work experience, focus less on coursework and more on degrees</li>
              <li>Include certifications and continuing education relevant to your field</li>
            </ul>
          </Card>
        </div>
      </ContentContainer>
      <Navigation>
        <Button variant="outline" onClick={prev}>
          <ArrowLeft className="w-4 h-4 mr-2" /> Back
        </Button>
        <Button onClick={next}>
          Next <ArrowRight className="w-4 h-4 ml-2" />
        </Button>
      </Navigation>
    </>
  );
};

const SkillsStep = ({ next, prev }: any) => {
  const { resumeContent, addSkill, updateSkill, removeSkill } = useResume();
  
  return (
    <>
      <h2 className="text-2xl font-bold mb-4">Skills</h2>
      <p className="text-gray-600 mb-6">
        Add relevant skills that showcase your expertise and qualifications for your target roles.
      </p>
      <ContentContainer>
        <div>
          <SkillForm
            skills={resumeContent.skills}
            onAdd={addSkill}
            onUpdate={updateSkill}
            onDelete={removeSkill}
          />
        </div>
        <div>
          <Card className="p-6 shadow-md">
            <h3 className="text-lg font-semibold mb-4">Tips:</h3>
            <ul className="list-disc list-inside space-y-2 text-gray-700">
              <li>Include a mix of technical (hard) and interpersonal (soft) skills</li>
              <li>Prioritize skills mentioned in job descriptions you're targeting</li>
              <li>Be honest about your skill levels - you may be asked about them in interviews</li>
              <li>Group skills by category for better organization</li>
              <li>Include relevant keywords for ATS optimization</li>
            </ul>
          </Card>
        </div>
      </ContentContainer>
      <Navigation>
        <Button variant="outline" onClick={prev}>
          <ArrowLeft className="w-4 h-4 mr-2" /> Back
        </Button>
        <Button onClick={next}>
          Next <ArrowRight className="w-4 h-4 ml-2" />
        </Button>
      </Navigation>
    </>
  );
};

const FinalizeStep = ({ prev }: any) => {
  const [isGenerating, setIsGenerating] = useState(false);
  const { resumeContent, saveResume } = useResume();
  const { toast } = useToast();
  const [location, setLocation] = useLocation();
  
  const handleFinish = async () => {
    try {
      setIsGenerating(true);
      await saveResume();
      toast({
        title: "Resume created!",
        description: "Your resume has been successfully created and saved."
      });
      setLocation("/");
    } catch (error) {
      toast({
        title: "Error creating resume",
        description: "There was an error saving your resume. Please try again.",
        variant: "destructive"
      });
    } finally {
      setIsGenerating(false);
    }
  };
  
  return (
    <>
      <h2 className="text-2xl font-bold mb-4">Finalize Your Resume</h2>
      <p className="text-gray-600 mb-6">
        Review your resume before finalizing. You can always edit it later.
      </p>
      <ContentContainer>
        <div>
          <Card className="p-6 shadow-md">
            <h3 className="text-lg font-semibold mb-4">Resume Summary</h3>
            <div className="space-y-4">
              <div>
                <h4 className="font-medium text-gray-700">Personal Information</h4>
                <p className="text-gray-600">{resumeContent.personalInfo.fullName}</p>
                <p className="text-gray-600">{resumeContent.personalInfo.email} • {resumeContent.personalInfo.phone}</p>
                <p className="text-gray-600">{resumeContent.personalInfo.location}</p>
              </div>
              
              <div>
                <h4 className="font-medium text-gray-700">Professional Summary</h4>
                <p className="text-gray-600 line-clamp-3">{resumeContent.summary || "No summary provided"}</p>
              </div>
              
              <div>
                <h4 className="font-medium text-gray-700">Experience</h4>
                <p className="text-gray-600">{resumeContent.experience.length} positions added</p>
              </div>
              
              <div>
                <h4 className="font-medium text-gray-700">Education</h4>
                <p className="text-gray-600">{resumeContent.education.length} education entries added</p>
              </div>
              
              <div>
                <h4 className="font-medium text-gray-700">Skills</h4>
                <p className="text-gray-600">{resumeContent.skills.length} skills added</p>
              </div>
            </div>
          </Card>
          
          <div className="mt-6">
            <h3 className="text-lg font-semibold mb-4">Next Steps</h3>
            <ul className="space-y-3">
              <li className="flex items-start">
                <div className="flex-shrink-0 h-5 w-5 text-green-500 mr-2">
                  <Check className="h-5 w-5" />
                </div>
                <p className="text-gray-700">Run an ATS check to optimize your resume</p>
              </li>
              <li className="flex items-start">
                <div className="flex-shrink-0 h-5 w-5 text-green-500 mr-2">
                  <Check className="h-5 w-5" />
                </div>
                <p className="text-gray-700">Match your resume against specific job descriptions</p>
              </li>
              <li className="flex items-start">
                <div className="flex-shrink-0 h-5 w-5 text-green-500 mr-2">
                  <Check className="h-5 w-5" />
                </div>
                <p className="text-gray-700">Export your resume in different formats</p>
              </li>
            </ul>
          </div>
        </div>
        <div>
          <div className="bg-white p-6 rounded-lg border border-gray-200 shadow-md h-full overflow-auto">
            <ResumeTemplate
              content={resumeContent}
              templateStyle={{
                colors: { primary: "#2563eb", secondary: "#e5e7eb" },
                layout: "standard",
                fonts: { title: "Inter", body: "Inter" }
              }}
              className="transform scale-90 origin-top"
            />
          </div>
        </div>
      </ContentContainer>
      <Navigation>
        <Button variant="outline" onClick={prev}>
          <ArrowLeft className="w-4 h-4 mr-2" /> Back
        </Button>
        <Button 
          onClick={handleFinish}
          disabled={isGenerating}
        >
          {isGenerating ? "Creating..." : "Create My Resume"}
        </Button>
      </Navigation>
    </>
  );
};

const stepConfig = [
  { 
    name: "Personal Info", 
    component: PersonalInfoStep, 
    icon: <User className="w-5 h-5" />
  },
  { 
    name: "Template", 
    component: TemplateStep, 
    icon: <FileText className="w-5 h-5" />
  },
  { 
    name: "Summary", 
    component: SummaryStep, 
    icon: <FileText className="w-5 h-5" />
  },
  { 
    name: "Experience", 
    component: ExperienceStep, 
    icon: <Briefcase className="w-5 h-5" />
  },
  { 
    name: "Education", 
    component: EducationStep, 
    icon: <GraduationCap className="w-5 h-5" />
  },
  { 
    name: "Skills", 
    component: SkillsStep, 
    icon: <Award className="w-5 h-5" />
  },
  { 
    name: "Finalize", 
    component: FinalizeStep, 
    icon: <Check className="w-5 h-5" />
  },
];

export function ResumeWizard() {
  const steps = useSteps({
    initialStep: 1,
    steps: [
      { component: PersonalInfoStep },
      { component: TemplateStep },
      { component: SummaryStep },
      { component: ExperienceStep },
      { component: EducationStep },
      { component: SkillsStep },
      { component: FinalizeStep }
    ]
  });
  
  const currentStep = steps.current; // 1-indexed

  return (
    <WizardContainer>
      <StepIndicator>
        {stepConfig.map((s, index) => (
          <StepItem 
            key={index} 
            active={currentStep === index + 1}
            completed={currentStep > index + 1}
          >
            <div className="step-number">
              {currentStep > index + 1 ? (
                <Check className="w-5 h-5" />
              ) : (
                index + 1
              )}
            </div>
            <span className="step-label">{s.name}</span>
          </StepItem>
        ))}
      </StepIndicator>
      
      <div className="bg-white p-6 sm:p-8 rounded-lg border border-gray-200 shadow-md">
        <StepContent>
          <Steps steps={steps} />
        </StepContent>
      </div>
    </WizardContainer>
  );
}