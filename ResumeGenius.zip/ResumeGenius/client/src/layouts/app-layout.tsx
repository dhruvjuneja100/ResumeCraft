import React from "react";
import { useLocation } from "wouter";
import { Button } from "@/components/ui/button";
import { Share, Save, User } from "lucide-react";
import { cn } from "@/lib/utils";

interface AppLayoutProps {
  children: React.ReactNode;
  onSave?: () => void;
  onShare?: () => void;
  showMobileActions?: boolean;
  className?: string;
}

export function AppLayout({
  children,
  onSave,
  onShare,
  showMobileActions = false,
  className,
}: AppLayoutProps) {
  const [location, setLocation] = useLocation();

  return (
    <div className="h-full flex flex-col">
      {/* Header */}
      <header className="bg-white border-b border-gray-200 px-4 py-3 flex items-center justify-between">
        <div className="flex items-center space-x-4">
          <div className="flex items-center">
            <svg
              className="w-8 h-8 text-primary"
              fill="currentColor"
              viewBox="0 0 24 24"
            >
              <path d="M19 5v14H5V5h14m0-2H5c-1.1 0-2 .9-2 2v14c0 1.1.9 2 2 2h14c1.1 0 2-.9 2-2V5c0-1.1-.9-2-2-2z" />
              <path d="M14 17H7v-2h7v2zm3-4H7v-2h10v2zm0-4H7V7h10v2z" />
            </svg>
            <span className="ml-2 text-xl font-bold text-gray-900">Resume Craft</span>
          </div>
          <nav className="hidden md:flex space-x-6">
            <a 
              href="#" 
              className={cn(
                location.includes("/builder") ? "text-primary font-medium" : "text-gray-500 hover:text-gray-900"
              )}
              onClick={(e) => {
                e.preventDefault();
                setLocation("/builder");
              }}
            >
              Builder
            </a>
            <a 
              href="#" 
              className={cn(
                location.includes("/templates") ? "text-primary font-medium" : "text-gray-500 hover:text-gray-900"
              )}
              onClick={(e) => {
                e.preventDefault();
                setLocation("/templates");
              }}
            >
              Templates
            </a>
            <a 
              href="#" 
              className={cn(
                location.includes("/ats-checker") ? "text-primary font-medium" : "text-gray-500 hover:text-gray-900"
              )}
              onClick={(e) => {
                e.preventDefault();
                setLocation("/ats-checker");
              }}
            >
              ATS Checker
            </a>
            <a 
              href="#" 
              className={cn(
                location.includes("/job-matcher") ? "text-primary font-medium" : "text-gray-500 hover:text-gray-900"
              )}
              onClick={(e) => {
                e.preventDefault();
                setLocation("/job-matcher");
              }}
            >
              Job Matcher
            </a>
          </nav>
        </div>
        <div className="flex items-center space-x-4">
          {onShare && (
            <Button
              variant="outline"
              size="sm"
              className="hidden sm:inline-flex"
              onClick={onShare}
            >
              <Share className="w-4 h-4 mr-2" />
              Share
            </Button>
          )}
          {onSave && (
            <Button size="sm" onClick={onSave}>
              <Save className="w-4 h-4 mr-2" />
              Save
            </Button>
          )}
          <div className="relative">
            <Button
              variant="ghost"
              className="bg-gray-800 flex text-sm rounded-full focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-primary"
              size="icon"
            >
              <span className="sr-only">Open user menu</span>
              <User className="h-5 w-5 text-white" />
            </Button>
          </div>
        </div>
      </header>

      {/* Main Content */}
      <div className={cn("flex-1 min-h-0 flex flex-col", className)}>
        {children}
      </div>

      {/* Mobile Action Bar (visible only on small screens) */}
      {showMobileActions && (
        <div className="lg:hidden bg-white border-t border-gray-200 px-4 py-3 flex justify-between items-center">
          <Button 
            variant="outline"
            onClick={() => setLocation(location.includes("/builder") ? "/ats-checker" : "/builder")}
          >
            {location.includes("/builder") ? (
              <>
                <svg className="w-4 h-4 mr-2" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
                  <path d="M9 12h6m-6 4h6m2 5H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z" strokeLinecap="round" strokeLinejoin="round" />
                </svg>
                Preview
              </>
            ) : (
              <>
                <svg className="w-4 h-4 mr-2" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
                  <path d="M15.232 5.232l3.536 3.536m-2.036-5.036a2.5 2.5 0 113.536 3.536L6.5 21.036H3v-3.572L16.732 3.732z" strokeLinecap="round" strokeLinejoin="round" />
                </svg>
                Edit
              </>
            )}
          </Button>
          {onSave && (
            <Button onClick={onSave}>
              <Save className="w-4 h-4 mr-2" />
              Save
            </Button>
          )}
        </div>
      )}
    </div>
  );
}

export default AppLayout;
