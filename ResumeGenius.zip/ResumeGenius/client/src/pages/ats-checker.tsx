import React, { useState, useEffect } from "react";
import { useParams, useLocation } from "wouter";
import { AppLayout } from "@/layouts/app-layout";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { useToast } from "@/hooks/use-toast";
import { useResume } from "@/hooks/use-resume";
import { ResumeTemplate } from "@/components/resume/resume-template";
import { useQuery } from "@tanstack/react-query";
import { KeywordBadge } from "@/components/resume/keyword-badge";
import { Loader2, CheckCircle, AlertTriangle, FileCheck } from "lucide-react";
import { Progress } from "@/components/ui/progress";

export default function ATSChecker() {
  const { id } = useParams();
  const resumeId = id ? parseInt(id) : undefined;
  const [location, setLocation] = useLocation();
  const { toast } = useToast();
  
  // Resume state
  const resume = useResume(resumeId);
  
  // Analysis state
  const [isAnalyzing, setIsAnalyzing] = useState(false);
  const [atsScore, setAtsScore] = useState(0);
  const [analysis, setAnalysis] = useState("");
  const [suggestions, setSuggestions] = useState<string[]>([]);
  const [keywords, setKeywords] = useState<{word: string, status: "matched" | "missing" | "suggested"}[]>([]);
  
  // Fetch templates for preview
  const { data: templates = [] } = useQuery({
    queryKey: ["/api/templates"],
  });

  // Run initial analysis when page loads
  useEffect(() => {
    if (resumeId && resume.resumeContent) {
      handleRunAnalysis();
    }
  }, [resumeId, resume.resumeContent]);

  // Handle run ATS analysis
  const handleRunAnalysis = async () => {
    if (!resume.resumeContent.personalInfo.fullName) {
      toast({
        title: "Resume incomplete",
        description: "Please add at least your name to the resume before analyzing.",
        variant: "destructive"
      });
      return;
    }
    
    setIsAnalyzing(true);
    
    try {
      const result = await resume.analyzeATS();
      
      setAtsScore(result.score);
      setAnalysis(result.analysis);
      setSuggestions(result.suggestions || []);
      
      // Mock keywords for demo (in real app, these would come from the API)
      const mockKeywords = [
        { word: "React", status: "matched" as const },
        { word: "JavaScript", status: "matched" as const },
        { word: "TypeScript", status: "matched" as const },
        { word: "Frontend", status: "matched" as const },
        { word: "API", status: "missing" as const },
        { word: "Leadership", status: "missing" as const },
        { word: "Team Management", status: "suggested" as const },
        { word: "Agile", status: "suggested" as const }
      ];
      setKeywords(mockKeywords);
      
      toast({
        title: "Analysis complete",
        description: `Your resume scored ${result.score}/100.`
      });
    } catch (error) {
      toast({
        title: "Error analyzing resume",
        description: "There was an error analyzing your resume. Please try again.",
        variant: "destructive"
      });
    } finally {
      setIsAnalyzing(false);
    }
  };

  // Get score color based on score
  const getScoreColor = () => {
    if (atsScore >= 80) return "text-green-500";
    if (atsScore >= 60) return "text-yellow-500";
    return "text-red-500";
  };

  // Get score background color
  const getScoreBackground = () => {
    if (atsScore >= 80) return "bg-green-100";
    if (atsScore >= 60) return "bg-yellow-100";
    return "bg-red-100";
  };

  // Handle edit resume button
  const handleEditResume = () => {
    if (resumeId) {
      setLocation(`/builder/${resumeId}`);
    } else {
      setLocation("/builder");
    }
  };

  return (
    <AppLayout
      onSave={handleEditResume}
      showMobileActions
    >
      <div className="flex-1 min-h-0 overflow-auto p-6 sm:p-8 bg-gray-50">
        <div className="max-w-6xl mx-auto">
          <div className="flex flex-col md:flex-row gap-8">
            {/* ATS Analysis */}
            <div className="flex-1">
              <h1 className="text-2xl font-bold text-gray-900 mb-6">ATS Resume Checker</h1>
              
              <Card className="mb-6">
                <CardContent className="p-6">
                  <div className="flex items-center justify-between mb-4">
                    <h2 className="text-xl font-semibold text-gray-900">Resume Score</h2>
                    <Button
                      onClick={handleRunAnalysis}
                      disabled={isAnalyzing}
                    >
                      {isAnalyzing ? (
                        <>
                          <Loader2 className="h-4 w-4 animate-spin mr-2" />
                          Analyzing...
                        </>
                      ) : (
                        <>
                          <FileCheck className="h-4 w-4 mr-2" />
                          Analyze Again
                        </>
                      )}
                    </Button>
                  </div>
                  
                  {atsScore > 0 ? (
                    <div className="flex flex-col md:flex-row items-center mb-4">
                      <div className={`text-5xl font-bold ${getScoreColor()} w-32 h-32 rounded-full ${getScoreBackground()} flex items-center justify-center`}>
                        {atsScore}
                      </div>
                      <div className="ml-0 md:ml-6 mt-4 md:mt-0 flex-1">
                        <div className="mb-2">
                          <div className="flex justify-between mb-1">
                            <span className="text-sm font-medium text-gray-700">ATS Compatibility</span>
                            <span className={`text-sm font-medium ${getScoreColor()}`}>{atsScore}%</span>
                          </div>
                          <Progress value={atsScore} className="h-2" />
                        </div>
                        <p className="text-gray-600">{analysis}</p>
                      </div>
                    </div>
                  ) : (
                    <div className="py-8 text-center text-gray-500">
                      {isAnalyzing ? (
                        <div className="flex flex-col items-center">
                          <Loader2 className="h-12 w-12 animate-spin mb-4 text-primary" />
                          <p>Analyzing your resume...</p>
                        </div>
                      ) : (
                        <div className="flex flex-col items-center">
                          <FileCheck className="h-12 w-12 mb-4 text-gray-400" />
                          <p>Click the "Analyze" button to check your resume's ATS compatibility.</p>
                        </div>
                      )}
                    </div>
                  )}
                  
                  {atsScore > 0 && (
                    <div className="mt-6 pt-6 border-t border-gray-200">
                      <div className="flex items-start">
                        {atsScore >= 70 ? (
                          <CheckCircle className="h-5 w-5 text-green-500 mt-0.5 mr-2" />
                        ) : (
                          <AlertTriangle className="h-5 w-5 text-yellow-500 mt-0.5 mr-2" />
                        )}
                        <div>
                          <h3 className="font-medium text-gray-900">Overall Assessment</h3>
                          <p className="mt-1 text-sm text-gray-600">
                            {atsScore >= 80
                              ? "Your resume is well-optimized for ATS systems. You have a high chance of passing automated screenings."
                              : atsScore >= 60
                              ? "Your resume is moderately optimized. Consider addressing the suggestions below to improve your chances."
                              : "Your resume may struggle with ATS systems. We strongly recommend implementing the suggestions below."}
                          </p>
                        </div>
                      </div>
                    </div>
                  )}
                </CardContent>
              </Card>
              
              {atsScore > 0 && (
                <>
                  {/* Keyword Analysis */}
                  <Card className="mb-6">
                    <CardContent className="p-6">
                      <h2 className="text-xl font-semibold text-gray-900 mb-4">Keyword Analysis</h2>
                      
                      <div className="space-y-4">
                        {keywords.filter(k => k.status === "matched").length > 0 && (
                          <div>
                            <h3 className="font-medium text-gray-900 mb-2">Found Keywords</h3>
                            <div className="flex flex-wrap gap-2">
                              {keywords
                                .filter(k => k.status === "matched")
                                .map((keyword, index) => (
                                  <KeywordBadge
                                    key={index}
                                    keyword={keyword.word}
                                    status="matched"
                                  />
                                ))}
                            </div>
                          </div>
                        )}
                        
                        {keywords.filter(k => k.status === "missing").length > 0 && (
                          <div>
                            <h3 className="font-medium text-gray-900 mb-2">Missing Keywords</h3>
                            <div className="flex flex-wrap gap-2">
                              {keywords
                                .filter(k => k.status === "missing")
                                .map((keyword, index) => (
                                  <KeywordBadge
                                    key={index}
                                    keyword={keyword.word}
                                    status="missing"
                                  />
                                ))}
                            </div>
                            <p className="mt-2 text-sm text-gray-600">
                              Consider adding these keywords to your resume if they're relevant to your experience.
                            </p>
                          </div>
                        )}
                        
                        {keywords.filter(k => k.status === "suggested").length > 0 && (
                          <div>
                            <h3 className="font-medium text-gray-900 mb-2">Suggested Keywords</h3>
                            <div className="flex flex-wrap gap-2">
                              {keywords
                                .filter(k => k.status === "suggested")
                                .map((keyword, index) => (
                                  <KeywordBadge
                                    key={index}
                                    keyword={keyword.word}
                                    status="suggested"
                                  />
                                ))}
                            </div>
                          </div>
                        )}
                      </div>
                    </CardContent>
                  </Card>
                  
                  {/* Improvement Suggestions */}
                  <Card>
                    <CardContent className="p-6">
                      <h2 className="text-xl font-semibold text-gray-900 mb-4">Improvement Suggestions</h2>
                      
                      {suggestions.length > 0 ? (
                        <ul className="space-y-3">
                          {suggestions.map((suggestion, index) => (
                            <li key={index} className="flex items-start">
                              <div className="mr-2 mt-0.5 text-blue-500">
                                <svg className="h-5 w-5" fill="currentColor" viewBox="0 0 20 20">
                                  <path fillRule="evenodd" d="M18 10a8 8 0 11-16 0 8 8 0 0116 0zm-7-4a1 1 0 11-2 0 1 1 0 012 0zM9 9a1 1 0 000 2v3a1 1 0 001 1h1a1 1 0 100-2v-3a1 1 0 00-1-1H9z" clipRule="evenodd" />
                                </svg>
                              </div>
                              <span className="text-gray-700">{suggestion}</span>
                            </li>
                          ))}
                        </ul>
                      ) : (
                        <p className="text-gray-600">No specific suggestions at this time.</p>
                      )}
                      
                      <div className="mt-6">
                        <Button onClick={handleEditResume}>
                          Edit Your Resume
                        </Button>
                      </div>
                    </CardContent>
                  </Card>
                </>
              )}
            </div>
            
            {/* Resume Preview */}
            <div className="w-full md:w-[400px] lg:w-[450px] flex-shrink-0">
              <div className="sticky top-8">
                <h2 className="text-xl font-semibold text-gray-900 mb-4">Your Resume</h2>
                <Card>
                  <CardContent className="p-4">
                    <div className="bg-white border border-gray-200 shadow-sm">
                      <ResumeTemplate
                        content={resume.resumeContent}
                        templateStyle={templates[0]?.structure}
                      />
                    </div>
                  </CardContent>
                </Card>
              </div>
            </div>
          </div>
        </div>
      </div>
    </AppLayout>
  );
}
