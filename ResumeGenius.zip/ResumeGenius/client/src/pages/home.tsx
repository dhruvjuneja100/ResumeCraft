import React, { useState } from "react";
import { useLocation } from "wouter";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { TemplateCard } from "@/components/resume/template-card";
import { EmptyState } from "@/components/ui/empty-state";
import { useQuery } from "@tanstack/react-query";
import { FileText, Plus, Briefcase, FileCheck } from "lucide-react";
import { ResumeTemplate, Resume } from "@shared/schema";

// Define a proper type for template structure
interface TemplateStructure {
  layout: "standard" | "sidebar" | "centered";
  colors: {
    primary: string;
    secondary: string;
  };
  fonts: {
    title: string;
    body: string;
  };
}
import { useAuth } from "@/hooks/use-auth";

export default function Home() {
  const [location, setLocation] = useLocation();
  const { user, logoutMutation } = useAuth();
  
  // Extend ResumeTemplate with our TemplateStructure interface
  type TemplateWithStructure = ResumeTemplate & { structure: TemplateStructure };
  
  const { data: templates = [], isLoading: isLoadingTemplates } = useQuery<TemplateWithStructure[]>({
    queryKey: ["/api/templates"],
    enabled: !!user,
  });

  const { data: resumes = [], isLoading: isLoadingResumes } = useQuery<Resume[]>({
    queryKey: ["/api/resumes"],
    enabled: !!user,
  });

  const handleNewResume = (templateId?: number) => {
    if (templateId) {
      setLocation(`/builder?template=${templateId}`);
    } else {
      setLocation("/builder");
    }
  };

  const handleOpenResume = (resumeId: number) => {
    setLocation(`/builder/${resumeId}`);
  };

  return (
    <div className="min-h-screen bg-gray-50">
      <header className="bg-white border-b border-gray-200 px-4 py-3">
        <div className="max-w-7xl mx-auto flex items-center justify-between">
          <div className="flex items-center">
            <svg
              className="w-8 h-8 text-primary"
              fill="currentColor"
              viewBox="0 0 24 24"
            >
              <path d="M19 5v14H5V5h14m0-2H5c-1.1 0-2 .9-2 2v14c0 1.1.9 2 2 2h14c1.1 0 2-.9 2-2V5c0-1.1-.9-2-2-2z" />
              <path d="M14 17H7v-2h7v2zm3-4H7v-2h10v2zm0-4H7V7h10v2z" />
            </svg>
            <span className="ml-2 text-xl font-bold text-gray-900">Resume Craft</span>
          </div>
          <div className="flex items-center space-x-4">
            <Button
              onClick={() => handleNewResume()}
              size="sm"
            >
              <Plus className="w-4 h-4 mr-2" />
              Create Resume
            </Button>
            <Button
              onClick={() => setLocation("/wizard")}
              size="sm"
              variant="outline"
            >
              <FileText className="w-4 h-4 mr-2" />
              Step-by-Step Wizard
            </Button>
            
            {user && (
              <div className="flex items-center space-x-4 ml-4 border-l pl-4 border-gray-200">
                <div className="text-sm">
                  <span className="text-gray-500">Signed in as </span>
                  <span className="font-medium">{user.username}</span>
                </div>
                <Button 
                  variant="ghost" 
                  size="sm"
                  onClick={() => logoutMutation.mutate()}
                >
                  Logout
                </Button>
              </div>
            )}
          </div>
        </div>
      </header>

      <main className="max-w-7xl mx-auto py-10 px-4">
        <section className="mb-12">
          <div className="flex items-center justify-between mb-6">
            <h2 className="text-2xl font-bold text-gray-900">Resume Templates</h2>
            <Button variant="outline" size="sm" onClick={() => setLocation("/templates")}>
              View All
            </Button>
          </div>

          {isLoadingTemplates ? (
            <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-6">
              {[1, 2, 3, 4].map((i) => (
                <Card key={i} className="h-64 animate-pulse">
                  <CardContent className="p-0 h-full bg-gray-200"></CardContent>
                </Card>
              ))}
            </div>
          ) : templates && templates.length > 0 ? (
            <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-6">
              {templates.map((template) => (
                <Card
                  key={template.id}
                  className="overflow-hidden cursor-pointer transition-all hover:shadow-md"
                  onClick={() => handleNewResume(template.id)}
                >
                  <div className="relative h-48 bg-gray-100 flex items-center justify-center">
                    <svg
                      className="w-full h-full text-gray-200"
                      fill="currentColor"
                      viewBox="0 0 800 600"
                    >
                      {/* Template preview based on structure */}
                      {template.structure && template.structure.layout === "standard" && (
                        <>
                          <rect x="100" y="50" width="600" height="80" rx="2" fill={`${template.structure.colors.primary}`} />
                          <rect x="100" y="150" width="600" height="40" rx="2" fill={`${template.structure.colors.secondary}`} />
                          <rect x="100" y="210" width="600" height="20" rx="2" fill="#e5e7eb" />
                          <rect x="100" y="240" width="600" height="20" rx="2" fill="#e5e7eb" />
                          <rect x="100" y="270" width="600" height="20" rx="2" fill="#e5e7eb" />
                          <rect x="100" y="320" width="600" height="40" rx="2" fill={`${template.structure.colors.secondary}`} />
                          <rect x="100" y="380" width="600" height="20" rx="2" fill="#e5e7eb" />
                          <rect x="100" y="410" width="600" height="20" rx="2" fill="#e5e7eb" />
                          <rect x="100" y="440" width="600" height="20" rx="2" fill="#e5e7eb" />
                          <rect x="100" y="490" width="600" height="40" rx="2" fill={`${template.structure.colors.secondary}`} />
                          <rect x="100" y="550" width="600" height="20" rx="2" fill="#e5e7eb" />
                        </>
                      )}
                      {template.structure && template.structure.layout === "sidebar" && (
                        <>
                          <rect x="100" y="50" width="200" height="500" rx="2" fill={`${template.structure.colors.primary}`} />
                          <rect x="320" y="50" width="380" height="60" rx="2" fill={`${template.structure.colors.secondary}`} />
                          <rect x="320" y="130" width="380" height="20" rx="2" fill="#e5e7eb" />
                          <rect x="320" y="160" width="380" height="20" rx="2" fill="#e5e7eb" />
                          <rect x="320" y="190" width="380" height="20" rx="2" fill="#e5e7eb" />
                          <rect x="320" y="240" width="380" height="40" rx="2" fill={`${template.structure.colors.secondary}`} />
                          <rect x="320" y="300" width="380" height="20" rx="2" fill="#e5e7eb" />
                          <rect x="320" y="330" width="380" height="20" rx="2" fill="#e5e7eb" />
                          <rect x="320" y="380" width="380" height="40" rx="2" fill={`${template.structure.colors.secondary}`} />
                          <rect x="320" y="440" width="380" height="20" rx="2" fill="#e5e7eb" />
                          <rect x="320" y="470" width="380" height="20" rx="2" fill="#e5e7eb" />
                          <rect x="320" y="500" width="380" height="20" rx="2" fill="#e5e7eb" />
                        </>
                      )}
                      {template.structure && template.structure.layout === "centered" && (
                        <>
                          <rect x="200" y="50" width="400" height="80" rx="2" fill={`${template.structure.colors.primary}`} />
                          <rect x="250" y="150" width="300" height="40" rx="2" fill={`${template.structure.colors.secondary}`} />
                          <rect x="200" y="210" width="400" height="20" rx="2" fill="#e5e7eb" />
                          <rect x="200" y="240" width="400" height="20" rx="2" fill="#e5e7eb" />
                          <rect x="200" y="270" width="400" height="20" rx="2" fill="#e5e7eb" />
                          <rect x="250" y="320" width="300" height="40" rx="2" fill={`${template.structure.colors.secondary}`} />
                          <rect x="200" y="380" width="400" height="20" rx="2" fill="#e5e7eb" />
                          <rect x="200" y="410" width="400" height="20" rx="2" fill="#e5e7eb" />
                          <rect x="250" y="460" width="300" height="40" rx="2" fill={`${template.structure.colors.secondary}`} />
                          <rect x="200" y="520" width="400" height="20" rx="2" fill="#e5e7eb" />
                          <rect x="200" y="550" width="400" height="20" rx="2" fill="#e5e7eb" />
                        </>
                      )}
                    </svg>
                  </div>
                  <CardContent className="p-4">
                    <h3 className="font-medium text-lg text-gray-900">{template.name}</h3>
                    <p className="text-sm text-gray-500 mt-1">{template.description}</p>
                  </CardContent>
                </Card>
              ))}
            </div>
          ) : (
            <EmptyState
              icon={<FileText className="h-12 w-12" />}
              title="No templates found"
              description="There are no templates available at the moment."
              action={{
                label: "Create Resume",
                onClick: () => handleNewResume(),
              }}
            />
          )}
        </section>

        <section>
          <div className="flex items-center justify-between mb-6">
            <h2 className="text-2xl font-bold text-gray-900">Your Resumes</h2>
          </div>

          {isLoadingResumes ? (
            <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-6">
              {[1, 2, 3].map((i) => (
                <Card key={i} className="h-40 animate-pulse">
                  <CardContent className="p-0 h-full bg-gray-200"></CardContent>
                </Card>
              ))}
            </div>
          ) : resumes && resumes.length > 0 ? (
            <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-6">
              {resumes.map((resume) => (
                <Card
                  key={resume.id}
                  className="overflow-hidden cursor-pointer transition-all hover:shadow-md"
                  onClick={() => handleOpenResume(resume.id)}
                >
                  <CardContent className="p-4">
                    <div className="flex justify-between items-start">
                      <div>
                        <h3 className="font-medium text-lg text-gray-900">
                          {resume.name}
                        </h3>
                        <p className="text-sm text-gray-500 mt-1">
                          Last edited:{" "}
                          {resume.updatedAt ? new Date(resume.updatedAt).toLocaleDateString() : "Recently"}
                        </p>
                      </div>
                      {resume.atsScore && (
                        <div className="bg-green-100 text-green-800 text-xs font-medium px-2 py-1 rounded-full">
                          ATS: {resume.atsScore}%
                        </div>
                      )}
                    </div>
                    <div className="mt-4 flex space-x-2">
                      <Button
                        variant="outline"
                        size="sm"
                        className="text-xs"
                        onClick={(e) => {
                          e.stopPropagation();
                          setLocation(`/ats-checker/${resume.id}`);
                        }}
                      >
                        <FileCheck className="h-3 w-3 mr-1" />
                        ATS Check
                      </Button>
                      <Button
                        variant="outline"
                        size="sm"
                        className="text-xs"
                        onClick={(e) => {
                          e.stopPropagation();
                          setLocation(`/job-matcher/${resume.id}`);
                        }}
                      >
                        <Briefcase className="h-3 w-3 mr-1" />
                        Job Match
                      </Button>
                    </div>
                  </CardContent>
                </Card>
              ))}

              {/* Create new resume card */}
              <Card
                className="border-2 border-dashed border-gray-300 bg-gray-50 hover:bg-gray-100 cursor-pointer flex items-center justify-center h-40"
                onClick={() => handleNewResume()}
              >
                <CardContent className="flex flex-col items-center justify-center p-6">
                  <Plus className="h-8 w-8 text-gray-400" />
                  <p className="mt-2 text-sm font-medium text-gray-500">
                    Create New Resume
                  </p>
                </CardContent>
              </Card>
            </div>
          ) : (
            <EmptyState
              icon={<FileText className="h-12 w-12" />}
              title="No resumes yet"
              description="Create your first resume or use our step-by-step wizard to get started."
              action={{
                label: "Create Resume",
                onClick: () => handleNewResume(),
              }}
              secondaryAction={{
                label: "Use Guided Wizard",
                onClick: () => setLocation("/wizard"),
              }}
            />
          )}
        </section>
      </main>
    </div>
  );
}
