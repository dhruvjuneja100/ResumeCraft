import React, { useState, useEffect } from "react";
import { useParams, useLocation } from "wouter";
import { AppLayout } from "@/layouts/app-layout";
import { ResumeSidebar } from "@/components/resume/resume-sidebar";
import { PersonalInfoForm } from "@/components/resume/personal-info-form";
import { SummaryForm } from "@/components/resume/summary-form";
import { ExperienceForm } from "@/components/resume/experience-form";
import { EducationForm } from "@/components/resume/education-form";
import { SkillForm } from "@/components/resume/skill-form";
import { ResumeTemplate as ResumeTemplateComponent } from "@/components/resume/resume-template";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { useToast } from "@/hooks/use-toast";
import { useResume } from "@/hooks/use-resume";
import { useQuery } from "@tanstack/react-query";
import { queryClient, apiRequest } from "@/lib/queryClient";
import { JobDescriptionMatcher } from "@/components/job-matcher/job-description-matcher";
import { TemplatePicker } from "@/components/resume/template-picker";
import { Plus } from "lucide-react";
import { v4 as uuidv4 } from "uuid";
import type { ResumeTemplate } from "@shared/schema";

export default function ResumeBuilder() {
  const { id } = useParams();
  const resumeId = id ? parseInt(id) : undefined;
  const [location, setLocation] = useLocation();
  const { toast } = useToast();
  
  // Get query params
  const params = new URLSearchParams(window.location.search);
  const templateIdParam = params.get('template');
  
  // Resume state
  const resume = useResume(resumeId);
  
  // UI state
  const [activeTab, setActiveTab] = useState("editor");
  const [expandedSections, setExpandedSections] = useState<string[]>(["personalInfo"]);
  const [isJobMatcherOpen, setIsJobMatcherOpen] = useState(false);
  const [selectedTemplateId, setSelectedTemplateId] = useState<number>(
    templateIdParam ? parseInt(templateIdParam) : 1
  );
  const [jobDescription, setJobDescription] = useState("");
  const [atsScore, setAtsScore] = useState(0);
  const [atsAnalysis, setAtsAnalysis] = useState("");

  // Fetch templates
  const { data: templates = [] as ResumeTemplate[] } = useQuery<ResumeTemplate[]>({
    queryKey: ["/api/templates"],
  });

  // Initialize with template if provided
  useEffect(() => {
    if (templateIdParam && !resumeId) {
      setSelectedTemplateId(parseInt(templateIdParam));
    }
  }, [templateIdParam, resumeId]);

  // Handle section toggle
  const handleToggleSection = (sectionId: string) => {
    if (expandedSections.includes(sectionId)) {
      setExpandedSections(expandedSections.filter(id => id !== sectionId));
    } else {
      setExpandedSections([...expandedSections, sectionId]);
    }
  };

  // Handle save resume
  const handleSaveResume = async () => {
    try {
      await resume.saveResume();
      toast({
        title: "Resume saved",
        description: "Your resume has been saved successfully."
      });
      
      // Redirect to the resume builder with ID if we've just created a new resume
      if (!resumeId && resume.resumeContent.personalInfo.fullName) {
        // TODO: Get the new resume ID and navigate to it
      }
    } catch (error) {
      toast({
        title: "Error saving resume",
        description: "There was an error saving your resume. Please try again.",
        variant: "destructive"
      });
    }
  };

  // Handle run ATS check
  const handleRunATSCheck = async () => {
    try {
      const result = await resume.analyzeATS();
      setAtsScore(result.score);
      setAtsAnalysis(result.analysis);
      toast({
        title: "ATS analysis complete",
        description: `Your resume scored ${result.score}/100. Check the sidebar for details.`
      });
    } catch (error) {
      toast({
        title: "Error analyzing resume",
        description: "There was an error analyzing your resume. Please try again.",
        variant: "destructive"
      });
    }
  };

  // Handle template selection
  const handleSelectTemplate = (templateId: number) => {
    setSelectedTemplateId(templateId);
    
    // Update the template ID for existing resume or new resume
    if (resumeId) {
      // Update existing resume's template
      apiRequest("PUT", `/api/resumes/${resumeId}`, { 
        templateId,
        content: resume.resumeContent 
      }).then(() => {
        // Invalidate the resume query to get latest data
        queryClient.invalidateQueries({ queryKey: [`/api/resumes/${resumeId}`] });
        toast({
          title: "Template updated",
          description: "Your resume template has been updated successfully."
        });
      }).catch((error: Error) => {
        toast({
          title: "Error updating template",
          description: error.message,
          variant: "destructive"
        });
      });
    }
    
    // The templateId will be used when creating a new resume
  };

  // Get the currently selected template
  const selectedTemplate = templates.find((t: ResumeTemplate) => t.id === selectedTemplateId) || templates[0];

  // Handle job matcher recommendations
  const handleApplyRecommendations = (analysis: any) => {
    if (analysis.recommendations && analysis.recommendations.length > 0) {
      // Update the resume content based on recommendations
      // For demo purposes, just show a toast
      toast({
        title: "Recommendations applied",
        description: "Your resume has been updated with the recommended changes."
      });
      
      // Store the job description for context
      setJobDescription(analysis.jobDescription);
    }
  };

  return (
    <AppLayout 
      onSave={handleSaveResume}
      onShare={() => {
        toast({
          title: "Share feature",
          description: "This feature is not implemented in the demo."
        });
      }}
      showMobileActions
    >
      <div className="flex-1 min-h-0 flex flex-col lg:flex-row">
        {/* Sidebar */}
        <ResumeSidebar
          templates={templates}
          selectedTemplateId={selectedTemplateId}
          onSelectTemplate={handleSelectTemplate}
          sections={resume.resumeContent.sections}
          expandedSections={expandedSections}
          onToggleSection={handleToggleSection}
          onReorderSections={resume.updateSectionOrder}
          atsScore={atsScore}
          atsAnalysis={atsAnalysis}
          onRunATSCheck={handleRunATSCheck}
        />

        {/* Main Content */}
        <div className="flex-1 min-w-0 flex flex-col overflow-hidden">
          {/* Tab Navigation */}
          <div className="bg-white border-b border-gray-200">
            <div className="px-6 sm:px-8 flex items-center space-x-4 overflow-x-auto">
              <Tabs value={activeTab} onValueChange={setActiveTab} className="w-full">
                <TabsList className="bg-transparent border-b-0">
                  <TabsTrigger 
                    value="editor"
                    className="data-[state=active]:border-b-2 data-[state=active]:border-primary data-[state=active]:text-primary rounded-none"
                  >
                    Resume Editor
                  </TabsTrigger>
                  <TabsTrigger 
                    value="ats"
                    className="data-[state=active]:border-b-2 data-[state=active]:border-primary data-[state=active]:text-primary rounded-none"
                  >
                    ATS Optimizer
                  </TabsTrigger>
                  <TabsTrigger 
                    value="job"
                    className="data-[state=active]:border-b-2 data-[state=active]:border-primary data-[state=active]:text-primary rounded-none"
                    onClick={() => setIsJobMatcherOpen(true)}
                  >
                    Job Description Matcher
                  </TabsTrigger>
                  <TabsTrigger 
                    value="export"
                    className="data-[state=active]:border-b-2 data-[state=active]:border-primary data-[state=active]:text-primary rounded-none"
                  >
                    Export Options
                  </TabsTrigger>
                </TabsList>
              </Tabs>
            </div>
          </div>

          {/* Split View */}
          <div className="flex-1 min-h-0 flex flex-col lg:flex-row">
            {/* Editor Panel */}
            <div className="flex-1 min-h-0 overflow-auto p-6 sm:p-8 bg-gray-50">
              <div className="max-w-3xl mx-auto">
                <Tabs value={activeTab} onValueChange={setActiveTab} className="w-full">
                  <TabsContent value="editor" className="mt-0">
                  {/* Template Picker */}
                  <TemplatePicker
                    templates={templates}
                    selectedTemplateId={selectedTemplateId}
                    onSelectTemplate={handleSelectTemplate}
                  />
                  
                  {/* Personal Information */}
                  {resume.resumeContent.sections.includes("personalInfo") && expandedSections.includes("personalInfo") && (
                    <PersonalInfoForm
                      personalInfo={resume.resumeContent.personalInfo}
                      onUpdate={resume.updatePersonalInfo}
                    />
                  )}
                  
                  {/* Summary */}
                  {resume.resumeContent.sections.includes("summary") && expandedSections.includes("summary") && (
                    <SummaryForm
                      summary={resume.resumeContent.summary || ""}
                      onUpdate={resume.updateSummary}
                      jobDescription={jobDescription}
                    />
                  )}

                  {/* Work Experience */}
                  {resume.resumeContent.sections.includes("experience") && expandedSections.includes("experience") && (
                    <div className="mb-8">
                      <div className="flex items-center justify-between mb-4">
                        <h2 className="text-xl font-semibold text-gray-900">Work Experience</h2>
                        <button
                          className="text-primary hover:text-primary-700 font-medium text-sm flex items-center"
                          onClick={() => resume.addExperience()}
                        >
                          <Plus className="h-4 w-4 mr-1" /> Add Position
                        </button>
                      </div>

                      {resume.resumeContent.experience.map((exp) => (
                        <ExperienceForm
                          key={exp.id}
                          experience={exp}
                          onToggleCollapse={() => {}}
                          onSave={(updatedExp) => resume.updateExperience(exp.id, updatedExp)}
                          onDuplicate={(id) => {
                            const expToDuplicate = resume.resumeContent.experience.find(e => e.id === id);
                            if (expToDuplicate) {
                              resume.addExperience({
                                ...expToDuplicate,
                                id: uuidv4(),
                                position: `${expToDuplicate.position} (Copy)`
                              });
                            }
                          }}
                          onDelete={(id) => resume.removeExperience(id)}
                          jobDescription={jobDescription}
                        />
                      ))}
                    </div>
                  )}

                  {/* Education */}
                  {resume.resumeContent.sections.includes("education") && expandedSections.includes("education") && (
                    <div className="mb-8">
                      <div className="flex items-center justify-between mb-4">
                        <h2 className="text-xl font-semibold text-gray-900">Education</h2>
                        <button
                          className="text-primary hover:text-primary-700 font-medium text-sm flex items-center"
                          onClick={() => resume.addEducation()}
                        >
                          <Plus className="h-4 w-4 mr-1" /> Add Education
                        </button>
                      </div>

                      {resume.resumeContent.education.map((edu) => (
                        <EducationForm
                          key={edu.id}
                          education={edu}
                          onToggleCollapse={() => {}}
                          onSave={(updatedEdu) => resume.updateEducation(edu.id, updatedEdu)}
                          onDuplicate={(id) => {
                            const eduToDuplicate = resume.resumeContent.education.find(e => e.id === id);
                            if (eduToDuplicate) {
                              resume.addEducation({
                                ...eduToDuplicate,
                                id: uuidv4(),
                                institution: `${eduToDuplicate.institution} (Copy)`
                              });
                            }
                          }}
                          onDelete={(id) => resume.removeEducation(id)}
                        />
                      ))}
                    </div>
                  )}

                  {/* Skills */}
                  {resume.resumeContent.sections.includes("skills") && expandedSections.includes("skills") && (
                    <SkillForm
                      skills={resume.resumeContent.skills}
                      onAdd={resume.addSkill}
                      onUpdate={resume.updateSkill}
                      onDelete={resume.removeSkill}
                      jobDescription={jobDescription}
                    />
                  )}
                </TabsContent>
                
                <TabsContent value="ats" className="mt-0">
                  <div className="bg-white p-6 rounded-lg border border-gray-200">
                    <h2 className="text-xl font-semibold mb-4">ATS Optimization</h2>
                    <p className="mb-4 text-gray-600">
                      The ATS (Applicant Tracking System) is software that employers use to manage job applications. Our ATS checker analyzes your resume to ensure it's optimized for these systems.
                    </p>
                    
                    <div className="mb-6">
                      <h3 className="text-lg font-medium mb-2">Current Score: {atsScore}/100</h3>
                      <div className="w-full bg-gray-200 rounded-full h-2.5">
                        <div 
                          className="bg-primary h-2.5 rounded-full" 
                          style={{ width: `${atsScore}%` }}
                        ></div>
                      </div>
                      <p className="mt-2 text-sm text-gray-600">{atsAnalysis}</p>
                    </div>
                    
                    <button
                      className="px-4 py-2 bg-primary text-white rounded-md hover:bg-primary-700 transition-colors"
                      onClick={handleRunATSCheck}
                      disabled={resume.isAnalyzing}
                    >
                      {resume.isAnalyzing ? "Analyzing..." : "Run ATS Analysis"}
                    </button>
                    
                    {resume.atsResult && (
                      <div className="mt-6 border-t border-gray-200 pt-6">
                        <h3 className="text-lg font-medium mb-3">Improvement Suggestions</h3>
                        <ul className="list-disc pl-5 space-y-2">
                          {resume.atsResult.suggestions.map((suggestion: string, index: number) => (
                            <li key={index} className="text-gray-700">{suggestion}</li>
                          ))}
                        </ul>
                      </div>
                    )}
                  </div>
                </TabsContent>
                
                <TabsContent value="export" className="mt-0">
                  <div className="bg-white p-6 rounded-lg border border-gray-200">
                    <h2 className="text-xl font-semibold mb-4">Export Options</h2>
                    <p className="mb-6 text-gray-600">
                      Export your resume in various formats to use for job applications.
                    </p>
                    
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                      <button
                        className="p-4 border border-gray-300 rounded-lg hover:bg-gray-50 transition-colors flex flex-col items-center justify-center"
                        onClick={() => {
                          toast({
                            title: "Export feature",
                            description: "PDF export is not implemented in the demo."
                          });
                        }}
                      >
                        <svg className="w-8 h-8 text-red-500 mb-2" fill="currentColor" viewBox="0 0 20 20">
                          <path d="M9 2a2 2 0 00-2 2v8a2 2 0 002 2h6a2 2 0 002-2V6.414A2 2 0 0016.414 5L14 2.586A2 2 0 0012.586 2H9z" />
                          <path d="M3 8a2 2 0 012-2h2a2 2 0 012 2v8a2 2 0 01-2 2H5a2 2 0 01-2-2V8z" />
                        </svg>
                        <span className="text-lg font-medium">PDF Format</span>
                        <span className="text-sm text-gray-500">Best for job applications</span>
                      </button>
                      
                      <button
                        className="p-4 border border-gray-300 rounded-lg hover:bg-gray-50 transition-colors flex flex-col items-center justify-center"
                        onClick={() => {
                          toast({
                            title: "Export feature",
                            description: "Word export is not implemented in the demo."
                          });
                        }}
                      >
                        <svg className="w-8 h-8 text-blue-500 mb-2" fill="currentColor" viewBox="0 0 20 20">
                          <path fillRule="evenodd" d="M4 4a2 2 0 012-2h4.586A2 2 0 0112 2.586L15.414 6A2 2 0 0116 7.414V16a2 2 0 01-2 2H6a2 2 0 01-2-2V4zm2 6a1 1 0 011-1h6a1 1 0 110 2H7a1 1 0 01-1-1zm1 3a1 1 0 100 2h6a1 1 0 100-2H7z" clipRule="evenodd" />
                        </svg>
                        <span className="text-lg font-medium">Word Document</span>
                        <span className="text-sm text-gray-500">Editable format</span>
                      </button>
                    </div>
                  </div>
                </TabsContent>
                </Tabs>
              </div>
            </div>

            {/* Preview Panel */}
            <div className="hidden lg:block lg:w-[500px] min-h-0 overflow-auto bg-white border-l border-gray-200">
              <div className="flex flex-col h-full">
                {/* Preview Header */}
                <div className="p-4 border-b border-gray-200 flex items-center justify-between">
                  <h2 className="text-lg font-medium text-gray-900">Live Preview</h2>
                  <div className="flex items-center space-x-2">
                    <button
                      className="p-1.5 text-gray-500 hover:text-gray-700 rounded-md hover:bg-gray-100"
                      title="Desktop view"
                    >
                      <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9.75 17L9 20l-1 1h8l-1-1-.75-3M3 13h18M5 17h14a2 2 0 002-2V5a2 2 0 00-2-2H5a2 2 0 00-2 2v10a2 2 0 002 2z" />
                      </svg>
                    </button>
                    <button
                      className="p-1.5 text-gray-500 hover:text-gray-700 rounded-md hover:bg-gray-100"
                      title="Tablet view"
                    >
                      <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 18h.01M7 21h10a2 2 0 002-2V5a2 2 0 00-2-2H7a2 2 0 00-2 2v14a2 2 0 002 2z" />
                      </svg>
                    </button>
                    <button
                      className="p-1.5 text-gray-500 hover:text-gray-700 rounded-md hover:bg-gray-100"
                      title="Mobile view"
                    >
                      <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 18h.01M8 21h8a2 2 0 002-2V5a2 2 0 00-2-2H8a2 2 0 00-2 2v14a2 2 0 002 2z" />
                      </svg>
                    </button>
                    <button
                      className="ml-2 px-3 py-1.5 text-sm bg-primary text-white rounded-md hover:bg-primary-700"
                      onClick={() => {
                        toast({
                          title: "Export feature",
                          description: "PDF export is not implemented in the demo."
                        });
                      }}
                    >
                      <svg xmlns="http://www.w3.org/2000/svg" className="h-4 w-4 inline-block mr-1" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4 16v1a3 3 0 003 3h10a3 3 0 003-3v-1m-4-4l-4 4m0 0l-4-4m4 4V4" />
                      </svg>
                      Export
                    </button>
                  </div>
                </div>

                {/* Resume Preview */}
                <div className="flex-1 overflow-auto p-6">
                  <ResumeTemplateComponent
                    content={resume.resumeContent}
                    templateStyle={
                      selectedTemplate?.structure 
                        ? selectedTemplate.structure as any 
                        : {
                            colors: { primary: "#2563eb", secondary: "#e5e7eb" },
                            layout: "standard",
                            fonts: { title: "Inter", body: "Inter" }
                          }
                    }
                    className="shadow-sm"
                  />
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Job Description Matcher Modal */}
      <JobDescriptionMatcher
        isOpen={isJobMatcherOpen}
        onClose={() => setIsJobMatcherOpen(false)}
        resumeContent={resume.resumeContent}
        onApplyRecommendations={handleApplyRecommendations}
      />
    </AppLayout>
  );
}
