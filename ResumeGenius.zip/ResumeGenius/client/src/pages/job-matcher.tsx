import React, { useState, useEffect } from "react";
import { useParams, useLocation } from "wouter";
import { AppLayout } from "@/layouts/app-layout";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { useToast } from "@/hooks/use-toast";
import { useResume } from "@/hooks/use-resume";
import { useQuery } from "@tanstack/react-query";
import { KeywordBadge } from "@/components/resume/keyword-badge";
import { Loader2, CheckCircle, AlertTriangle, FileCheck, Download } from "lucide-react";
import { Progress } from "@/components/ui/progress";
import { useMutation } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";

export default function JobMatcher() {
  const { id } = useParams();
  const resumeId = id ? parseInt(id) : undefined;
  const [location, setLocation] = useLocation();
  const { toast } = useToast();
  
  // Resume state
  const resume = useResume(resumeId);
  
  // Analysis state
  const [jobDescription, setJobDescription] = useState("");
  const [jobUrl, setJobUrl] = useState("");
  const [isAnalyzing, setIsAnalyzing] = useState(false);
  const [matchScore, setMatchScore] = useState(0);
  const [matchedKeywords, setMatchedKeywords] = useState<string[]>([]);
  const [missingKeywords, setMissingKeywords] = useState<string[]>([]);
  const [recommendations, setRecommendations] = useState<string[]>([]);
  
  // Job scraping mutation
  const jobScrapeMutation = useMutation({
    mutationFn: async (url: string) => {
      // In a real application, this would call an API to scrape the job listing
      // For this demo, we'll return a mock response
      return new Promise<string>((resolve) => {
        setTimeout(() => {
          resolve(`
            Senior Frontend Developer
            
            We are looking for a talented Senior Frontend Developer with experience in React, TypeScript, and modern JavaScript frameworks. The ideal candidate will have 5+ years of experience building responsive web applications and leading development teams.
            
            Responsibilities:
            - Develop and maintain responsive web applications using React
            - Write clean, maintainable, and efficient code
            - Lead a team of frontend developers
            - Implement best practices for performance and scalability
            - Work closely with UX/UI designers and backend developers
            
            Requirements:
            - 5+ years of experience with frontend development
            - Strong proficiency in React, TypeScript, and JavaScript
            - Experience with state management (Redux, Context API)
            - Knowledge of modern frontend build tools (Webpack, Vite)
            - Experience with version control systems (Git)
            - Experience with testing frameworks (Jest, React Testing Library)
            - Excellent communication and teamwork skills
            
            Nice to have:
            - Experience with GraphQL
            - Knowledge of server-side rendering
            - Experience with CI/CD pipelines
            - Knowledge of AWS or other cloud services
          `);
        }, 1500);
      });
    },
    onSuccess: (data) => {
      setJobDescription(data);
      toast({
        title: "Job description fetched",
        description: "The job description has been retrieved successfully."
      });
    },
    onError: () => {
      toast({
        title: "Error fetching job description",
        description: "There was an error retrieving the job description. Please try again or paste it manually.",
        variant: "destructive"
      });
    }
  });

  // Match analysis mutation
  const matchAnalysisMutation = useMutation({
    mutationFn: async () => {
      const response = await apiRequest("POST", "/api/job/match", {
        resumeContent: resume.resumeContent,
        jobDescription
      });
      return response.json();
    },
    onSuccess: (data) => {
      setMatchScore(data.matchScore || 0);
      setMatchedKeywords(data.matchedKeywords || []);
      setMissingKeywords(data.missingKeywords || []);
      setRecommendations(data.recommendations || []);
      
      toast({
        title: "Match analysis complete",
        description: `Your resume has a ${data.matchScore}% match with this job description.`
      });
    },
    onError: () => {
      toast({
        title: "Error analyzing job match",
        description: "There was an error analyzing your resume against this job description. Please try again.",
        variant: "destructive"
      });
    }
  });

  // Handle fetch job description
  const handleFetchJobDescription = () => {
    if (!jobUrl) {
      toast({
        title: "URL required",
        description: "Please enter a job listing URL to fetch the description.",
        variant: "destructive"
      });
      return;
    }
    
    jobScrapeMutation.mutate(jobUrl);
  };

  // Handle match analysis
  const handleAnalyzeMatch = () => {
    if (!jobDescription) {
      toast({
        title: "Job description required",
        description: "Please enter a job description to analyze the match.",
        variant: "destructive"
      });
      return;
    }
    
    matchAnalysisMutation.mutate();
  };

  // Get score color based on score
  const getScoreColor = () => {
    if (matchScore >= 80) return "text-green-500";
    if (matchScore >= 60) return "text-yellow-500";
    return "text-red-500";
  };

  // Handle edit resume button
  const handleEditResume = () => {
    if (resumeId) {
      setLocation(`/builder/${resumeId}`);
    } else {
      setLocation("/builder");
    }
  };

  return (
    <AppLayout
      onSave={handleEditResume}
      showMobileActions
    >
      <div className="flex-1 min-h-0 overflow-auto p-6 sm:p-8 bg-gray-50">
        <div className="max-w-6xl mx-auto">
          <h1 className="text-2xl font-bold text-gray-900 mb-6">Job Description Matcher</h1>
          
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
            {/* Job Description Input */}
            <div>
              <Card className="mb-6">
                <CardContent className="p-6">
                  <h2 className="text-xl font-semibold text-gray-900 mb-4">Enter Job Description</h2>
                  
                  <div className="mb-4">
                    <label className="block text-sm font-medium text-gray-700 mb-1">
                      Paste Job Description
                    </label>
                    <Textarea
                      rows={10}
                      placeholder="Paste the job description here..."
                      value={jobDescription}
                      onChange={(e) => setJobDescription(e.target.value)}
                      className="resize-none"
                    />
                  </div>
                  
                  <div className="mb-4">
                    <label className="block text-sm font-medium text-gray-700 mb-1">
                      Or Enter Job URL
                    </label>
                    <div className="flex">
                      <Input
                        type="text"
                        placeholder="https://example.com/job-posting"
                        className="rounded-l-md"
                        value={jobUrl}
                        onChange={(e) => setJobUrl(e.target.value)}
                      />
                      <Button
                        className="rounded-l-none"
                        onClick={handleFetchJobDescription}
                        disabled={jobScrapeMutation.isPending || !jobUrl}
                      >
                        {jobScrapeMutation.isPending ? (
                          <Loader2 className="h-4 w-4 animate-spin" />
                        ) : (
                          <Download className="h-4 w-4" />
                        )}
                      </Button>
                    </div>
                  </div>
                  
                  <Button 
                    className="w-full" 
                    onClick={handleAnalyzeMatch} 
                    disabled={matchAnalysisMutation.isPending || !jobDescription}
                  >
                    {matchAnalysisMutation.isPending ? (
                      <>
                        <Loader2 className="h-4 w-4 animate-spin mr-2" />
                        Analyzing...
                      </>
                    ) : (
                      <>
                        <FileCheck className="h-4 w-4 mr-2" />
                        Analyze Match
                      </>
                    )}
                  </Button>
                </CardContent>
              </Card>
              
              {/* Match Results */}
              {matchScore > 0 && (
                <Card>
                  <CardContent className="p-6">
                    <h2 className="text-xl font-semibold text-gray-900 mb-4">Match Results</h2>
                    
                    <div className="mb-6">
                      <div className="flex items-center mb-2">
                        <span className="text-lg font-medium text-gray-700 mr-4">Match Score:</span>
                        <div className="flex-1">
                          <Progress value={matchScore} className="h-2" />
                        </div>
                        <span className={`ml-2 text-lg font-bold ${getScoreColor()}`}>{matchScore}%</span>
                      </div>
                      
                      <div className="flex items-start">
                        {matchScore >= 70 ? (
                          <CheckCircle className="h-5 w-5 text-green-500 mt-0.5 mr-2" />
                        ) : (
                          <AlertTriangle className="h-5 w-5 text-yellow-500 mt-0.5 mr-2" />
                        )}
                        <p className="text-gray-600">
                          {matchScore >= 80
                            ? "Great match! Your resume is well-aligned with this job description."
                            : matchScore >= 60
                            ? "Good match. With a few adjustments, your resume could be even better aligned with this position."
                            : "Your resume could use significant improvements to better match this job description."}
                        </p>
                      </div>
                    </div>
                    
                    <div className="space-y-6">
                      {/* Matched Keywords */}
                      {matchedKeywords.length > 0 && (
                        <div>
                          <h3 className="font-medium text-gray-900 mb-2">Matched Keywords</h3>
                          <div className="flex flex-wrap gap-2">
                            {matchedKeywords.map((keyword, index) => (
                              <KeywordBadge
                                key={index}
                                keyword={keyword}
                                status="matched"
                              />
                            ))}
                          </div>
                        </div>
                      )}
                      
                      {/* Missing Keywords */}
                      {missingKeywords.length > 0 && (
                        <div>
                          <h3 className="font-medium text-gray-900 mb-2">Missing Keywords</h3>
                          <div className="flex flex-wrap gap-2">
                            {missingKeywords.map((keyword, index) => (
                              <KeywordBadge
                                key={index}
                                keyword={keyword}
                                status="missing"
                                onAdd={() => {
                                  // In a real app, this would offer to add the keyword to the resume
                                  toast({
                                    title: "Add keyword",
                                    description: `In a full implementation, this would add "${keyword}" to your resume.`
                                  });
                                }}
                              />
                            ))}
                          </div>
                        </div>
                      )}
                    </div>
                  </CardContent>
                </Card>
              )}
            </div>
            
            {/* Recommendations */}
            <div>
              {matchScore > 0 ? (
                <Card>
                  <CardContent className="p-6">
                    <h2 className="text-xl font-semibold text-gray-900 mb-4">Recommended Improvements</h2>
                    
                    {recommendations.length > 0 ? (
                      <ul className="space-y-4">
                        {recommendations.map((recommendation, index) => (
                          <li key={index} className="flex items-start">
                            <div className="mr-3 mt-0.5 text-blue-500">
                              <svg className="h-5 w-5" fill="currentColor" viewBox="0 0 20 20">
                                <path fillRule="evenodd" d="M18 10a8 8 0 11-16 0 8 8 0 0116 0zm-7-4a1 1 0 11-2 0 1 1 0 012 0zM9 9a1 1 0 000 2v3a1 1 0 001 1h1a1 1 0 100-2v-3a1 1 0 00-1-1H9z" clipRule="evenodd" />
                              </svg>
                            </div>
                            <div>
                              <p className="text-gray-700">{recommendation}</p>
                              <div className="mt-2">
                                <Button 
                                  variant="outline" 
                                  size="sm"
                                  onClick={() => {
                                    toast({
                                      title: "Apply recommendation",
                                      description: "In a full implementation, this would apply the recommendation to your resume."
                                    });
                                  }}
                                >
                                  Apply This Suggestion
                                </Button>
                              </div>
                            </div>
                          </li>
                        ))}
                      </ul>
                    ) : (
                      <p className="text-gray-600">No specific recommendations at this time.</p>
                    )}
                    
                    <div className="mt-8">
                      <Button onClick={handleEditResume}>
                        Edit Your Resume
                      </Button>
                    </div>
                  </CardContent>
                </Card>
              ) : (
                <Card>
                  <CardContent className="p-6">
                    <div className="py-16 text-center text-gray-500">
                      <div className="flex flex-col items-center">
                        <FileCheck className="h-16 w-16 mb-4 text-gray-300" />
                        <h3 className="text-lg font-medium text-gray-700 mb-2">No Analysis Yet</h3>
                        <p className="max-w-md mx-auto">
                          Enter a job description and click "Analyze Match" to see how well your resume aligns with the job requirements.
                        </p>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              )}
              
              {/* Tips for Optimization */}
              <Card className="mt-6">
                <CardContent className="p-6">
                  <h2 className="text-xl font-semibold text-gray-900 mb-4">Tips for Job Optimization</h2>
                  
                  <ul className="space-y-3">
                    <li className="flex items-start">
                      <div className="mr-3 mt-0.5 text-green-500">
                        <svg className="h-5 w-5" fill="currentColor" viewBox="0 0 20 20">
                          <path fillRule="evenodd" d="M10 18a8 8 0 100-16 8 8 0 000 16zm3.707-9.293a1 1 0 00-1.414-1.414L9 10.586 7.707 9.293a1 1 0 00-1.414 1.414l2 2a1 1 0 001.414 0l4-4z" clipRule="evenodd" />
                        </svg>
                      </div>
                      <p className="text-gray-700">
                        <span className="font-medium">Match keywords: </span>
                        Incorporate keywords from the job description naturally in your resume.
                      </p>
                    </li>
                    <li className="flex items-start">
                      <div className="mr-3 mt-0.5 text-green-500">
                        <svg className="h-5 w-5" fill="currentColor" viewBox="0 0 20 20">
                          <path fillRule="evenodd" d="M10 18a8 8 0 100-16 8 8 0 000 16zm3.707-9.293a1 1 0 00-1.414-1.414L9 10.586 7.707 9.293a1 1 0 00-1.414 1.414l2 2a1 1 0 001.414 0l4-4z" clipRule="evenodd" />
                        </svg>
                      </div>
                      <p className="text-gray-700">
                        <span className="font-medium">Quantify achievements: </span>
                        Use numbers and metrics to demonstrate your impact.
                      </p>
                    </li>
                    <li className="flex items-start">
                      <div className="mr-3 mt-0.5 text-green-500">
                        <svg className="h-5 w-5" fill="currentColor" viewBox="0 0 20 20">
                          <path fillRule="evenodd" d="M10 18a8 8 0 100-16 8 8 0 000 16zm3.707-9.293a1 1 0 00-1.414-1.414L9 10.586 7.707 9.293a1 1 0 00-1.414 1.414l2 2a1 1 0 001.414 0l4-4z" clipRule="evenodd" />
                        </svg>
                      </div>
                      <p className="text-gray-700">
                        <span className="font-medium">Use action verbs: </span>
                        Begin bullet points with strong action verbs relevant to the role.
                      </p>
                    </li>
                    <li className="flex items-start">
                      <div className="mr-3 mt-0.5 text-green-500">
                        <svg className="h-5 w-5" fill="currentColor" viewBox="0 0 20 20">
                          <path fillRule="evenodd" d="M10 18a8 8 0 100-16 8 8 0 000 16zm3.707-9.293a1 1 0 00-1.414-1.414L9 10.586 7.707 9.293a1 1 0 00-1.414 1.414l2 2a1 1 0 001.414 0l4-4z" clipRule="evenodd" />
                        </svg>
                      </div>
                      <p className="text-gray-700">
                        <span className="font-medium">Tailor for each job: </span>
                        Create a custom version of your resume for each application.
                      </p>
                    </li>
                  </ul>
                </CardContent>
              </Card>
            </div>
          </div>
        </div>
      </div>
    </AppLayout>
  );
}
