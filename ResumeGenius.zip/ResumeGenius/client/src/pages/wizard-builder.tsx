import React from 'react';
import { ResumeWizard } from '@/components/wizard/resume-wizard';
import { AppLayout } from '@/layouts/app-layout';

export default function WizardBuilder() {
  return (
    <AppLayout>
      <div className="min-h-screen bg-gray-50 py-6">
        <ResumeWizard />
      </div>
    </AppLayout>
  );
}