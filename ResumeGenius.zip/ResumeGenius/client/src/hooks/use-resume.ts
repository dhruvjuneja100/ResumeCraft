import { useState, useEffect } from "react";
import { useQuery, useQueryClient, useMutation } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";
import { v4 as uuidv4 } from "uuid";
import {
  ResumeContent,
  resumeContentSchema,
  Experience,
  Education,
  Skill,
  Project,
  personalInfoSchema,
  educationSchema,
  experienceSchema,
  skillSchema,
  projectSchema,
} from "@shared/schema";

// Default resume content
const defaultResumeContent: ResumeContent = {
  personalInfo: {
    fullName: "",
    email: "",
    phone: "",
    location: "",
    headline: "",
    website: "",
    linkedin: "",
    github: "",
  },
  summary: "",
  education: [],
  experience: [],
  skills: [],
  projects: [],
  sections: [
    "personalInfo",
    "summary",
    "experience",
    "education",
    "skills",
    "projects",
  ],
};

export function useResume(resumeId?: number) {
  const queryClient = useQueryClient();
  const [localContent, setLocalContent] = useState<ResumeContent>(defaultResumeContent);
  
  // Fetch resume if ID is provided
  const { data: resumeData, isLoading, error } = useQuery<{
    id: number;
    name: string;
    userId: number;
    templateId: number;
    content: ResumeContent;
    atsScore: number | null;
    createdAt: string;
    updatedAt: string;
  }>({
    queryKey: resumeId ? [`/api/resumes/${resumeId}`] : [],
    enabled: !!resumeId,
  });
  
  useEffect(() => {
    if (resumeData && 'content' in resumeData) {
      setLocalContent(resumeData.content);
    }
  }, [resumeData]);
  
  // Handle saving resume
  const saveResumeMutation = useMutation({
    mutationFn: async (content: ResumeContent) => {
      if (resumeId) {
        // Update existing resume
        return apiRequest("PUT", `/api/resumes/${resumeId}`, { content });
      } else {
        // Create new resume
        // Get templateId from URL search params if available
        const urlParams = new URLSearchParams(window.location.search);
        const templateId = urlParams.get('template') ? 
          parseInt(urlParams.get('template')!) : 1;
        
        return apiRequest("POST", "/api/resumes", {
          name: content.personalInfo.fullName || "Untitled Resume",
          templateId: templateId, // Use selected template
          content,
        });
      }
    },
    onSuccess: (response) => {
      queryClient.invalidateQueries({ queryKey: ["/api/resumes"] });
      if (resumeId) {
        queryClient.invalidateQueries({ queryKey: [`/api/resumes/${resumeId}`] });
      } else {
        // If it's a new resume, get the ID from the response and redirect
        response.json().then(data => {
          if (data && data.id) {
            window.location.href = `/builder/${data.id}`;
          }
        });
      }
    },
  });
  
  // Handle ATS analysis
  const atsAnalysisMutation = useMutation({
    mutationFn: async (resumeContent: ResumeContent) => {
      const response = await apiRequest("POST", "/api/ats/analyze", { resumeContent });
      return response.json();
    },
  });
  
  // Handle AI enhancement
  const aiEnhanceMutation = useMutation({
    mutationFn: async ({ 
      sectionType, 
      sectionContent, 
      jobDescription 
    }: { 
      sectionType: string; 
      sectionContent: any; 
      jobDescription?: string 
    }) => {
      const response = await apiRequest("POST", "/api/ai/enhance", {
        sectionType,
        sectionContent,
        jobDescription,
      });
      return response.json();
    },
  });
  
  // Helper functions to update resume content
  const updatePersonalInfo = (info: Partial<typeof localContent.personalInfo>) => {
    setLocalContent((prev) => ({
      ...prev,
      personalInfo: {
        ...prev.personalInfo,
        ...info,
      },
    }));
  };
  
  const updateSummary = (summary: string) => {
    setLocalContent((prev) => ({
      ...prev,
      summary,
    }));
  };
  
  const addExperience = (experience?: Partial<Experience>) => {
    const newExperience: Experience = {
      id: uuidv4(),
      company: "",
      position: "",
      startDate: "",
      endDate: "",
      location: "",
      description: "",
      achievements: [],
      current: false,
      ...experience,
    };
    
    setLocalContent((prev) => ({
      ...prev,
      experience: [...prev.experience, newExperience],
    }));
    
    return newExperience.id;
  };
  
  const updateExperience = (id: string, experience: Partial<Experience>) => {
    setLocalContent((prev) => ({
      ...prev,
      experience: prev.experience.map((item) =>
        item.id === id ? { ...item, ...experience } : item
      ),
    }));
  };
  
  const removeExperience = (id: string) => {
    setLocalContent((prev) => ({
      ...prev,
      experience: prev.experience.filter((item) => item.id !== id),
    }));
  };
  
  const addEducation = (education?: Partial<Education>) => {
    const newEducation: Education = {
      id: uuidv4(),
      institution: "",
      degree: "",
      field: "",
      startDate: "",
      endDate: "",
      location: "",
      description: "",
      gpa: "",
      ...education,
    };
    
    setLocalContent((prev) => ({
      ...prev,
      education: [...prev.education, newEducation],
    }));
    
    return newEducation.id;
  };
  
  const updateEducation = (id: string, education: Partial<Education>) => {
    setLocalContent((prev) => ({
      ...prev,
      education: prev.education.map((item) =>
        item.id === id ? { ...item, ...education } : item
      ),
    }));
  };
  
  const removeEducation = (id: string) => {
    setLocalContent((prev) => ({
      ...prev,
      education: prev.education.filter((item) => item.id !== id),
    }));
  };
  
  const addSkill = (skill?: Partial<Skill>) => {
    const newSkill: Skill = {
      id: uuidv4(),
      name: "",
      level: 3,
      keywords: [],
      ...skill,
    };
    
    setLocalContent((prev) => ({
      ...prev,
      skills: [...prev.skills, newSkill],
    }));
    
    return newSkill.id;
  };
  
  const updateSkill = (id: string, skill: Partial<Skill>) => {
    setLocalContent((prev) => ({
      ...prev,
      skills: prev.skills.map((item) =>
        item.id === id ? { ...item, ...skill } : item
      ),
    }));
  };
  
  const removeSkill = (id: string) => {
    setLocalContent((prev) => ({
      ...prev,
      skills: prev.skills.filter((item) => item.id !== id),
    }));
  };
  
  const addProject = (project?: Partial<Project>) => {
    const newProject: Project = {
      id: uuidv4(),
      name: "",
      description: "",
      url: "",
      startDate: "",
      endDate: "",
      highlights: [],
      ...project,
    };
    
    setLocalContent((prev) => ({
      ...prev,
      projects: [...prev.projects, newProject],
    }));
    
    return newProject.id;
  };
  
  const updateProject = (id: string, project: Partial<Project>) => {
    setLocalContent((prev) => ({
      ...prev,
      projects: prev.projects.map((item) =>
        item.id === id ? { ...item, ...project } : item
      ),
    }));
  };
  
  const removeProject = (id: string) => {
    setLocalContent((prev) => ({
      ...prev,
      projects: prev.projects.filter((item) => item.id !== id),
    }));
  };
  
  const updateSectionOrder = (sections: string[]) => {
    setLocalContent((prev) => ({
      ...prev,
      sections,
    }));
  };
  
  const saveResume = () => {
    return saveResumeMutation.mutateAsync(localContent);
  };
  
  const analyzeATS = () => {
    return atsAnalysisMutation.mutateAsync(localContent);
  };
  
  const enhanceWithAI = (
    sectionType: string,
    sectionContent: any,
    jobDescription?: string
  ) => {
    return aiEnhanceMutation.mutateAsync({
      sectionType,
      sectionContent,
      jobDescription,
    });
  };
  
  return {
    resumeContent: localContent,
    isLoading,
    error,
    
    // Basic operations
    updatePersonalInfo,
    updateSummary,
    updateSectionOrder,
    
    // Experience
    addExperience,
    updateExperience,
    removeExperience,
    
    // Education
    addEducation,
    updateEducation,
    removeEducation,
    
    // Skills
    addSkill,
    updateSkill,
    removeSkill,
    
    // Projects
    addProject,
    updateProject,
    removeProject,
    
    // API operations
    saveResume,
    isSaving: saveResumeMutation.isPending,
    
    // ATS analysis
    analyzeATS,
    isAnalyzing: atsAnalysisMutation.isPending,
    atsResult: atsAnalysisMutation.data,
    
    // AI enhancement
    enhanceWithAI,
    isEnhancing: aiEnhanceMutation.isPending,
    enhancementResult: aiEnhanceMutation.data,
  };
}
