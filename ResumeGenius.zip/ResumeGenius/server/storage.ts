import { 
  type User, 
  type InsertUser, 
  type Resume, 
  type InsertResume, 
  type ResumeTemplate, 
  type InsertResumeTemplate,
  type JobMatch,
  type InsertJobMatch,
  users,
  resumes,
  resumeTemplates,
  jobMatches
} from "@shared/schema";
import { v4 as uuidv4 } from 'uuid';
import { db } from "./db";
import { eq, and } from "drizzle-orm";
import session from "express-session";
import connectPg from "connect-pg-simple";
import { pool } from "./db";

// Define the storage interface
export interface IStorage {
  // User methods
  getUser(id: number): Promise<User | undefined>;
  getUserByUsername(username: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;
  
  // Resume methods
  getResume(id: number): Promise<Resume | undefined>;
  getResumesByUserId(userId: number): Promise<Resume[]>;
  createResume(resume: InsertResume): Promise<Resume>;
  updateResume(id: number, resume: Partial<InsertResume>): Promise<Resume | undefined>;
  deleteResume(id: number): Promise<boolean>;
  
  // Template methods
  getResumeTemplate(id: number): Promise<ResumeTemplate | undefined>;
  getAllResumeTemplates(): Promise<ResumeTemplate[]>;
  createResumeTemplate(template: InsertResumeTemplate): Promise<ResumeTemplate>;
  
  // Job match methods
  getJobMatch(id: number): Promise<JobMatch | undefined>;
  getJobMatchesByResumeId(resumeId: number): Promise<JobMatch[]>;
  createJobMatch(jobMatch: InsertJobMatch): Promise<JobMatch>;
  updateJobMatch(id: number, jobMatch: Partial<InsertJobMatch>): Promise<JobMatch | undefined>;
  
  // Session store
  sessionStore: session.Store;
}

// Set up PostgreSQL session store
const PostgresSessionStore = connectPg(session);

// Database storage implementation
export class DatabaseStorage implements IStorage {
  sessionStore: session.Store;
  
  constructor() {
    this.sessionStore = new PostgresSessionStore({ 
      pool,
      createTableIfMissing: true
    });
  }
  
  // Initialize with default templates if they don't exist
  async init() {
    const existingTemplates = await this.getAllResumeTemplates();
    
    if (existingTemplates.length === 0) {
      console.log("Initializing default resume templates");
      const templates = [
        {
          name: "Professional",
          description: "A clean and professional template for corporate environments",
          thumbnail: "professional.svg",
          structure: {
            layout: "standard",
            colors: {
              primary: "#2563eb",
              secondary: "#e5e7eb"
            },
            fonts: {
              title: "Inter",
              body: "Inter"
            }
          }
        },
        {
          name: "Modern",
          description: "A contemporary design with a focus on readability",
          thumbnail: "modern.svg",
          structure: {
            layout: "sidebar",
            colors: {
              primary: "#3730a3",
              secondary: "#e0e7ff"
            },
            fonts: {
              title: "Inter",
              body: "Inter"
            }
          }
        },
        {
          name: "Executive",
          description: "An elegant template for senior positions",
          thumbnail: "executive.svg",
          structure: {
            layout: "centered",
            colors: {
              primary: "#1e3a8a",
              secondary: "#eff6ff"
            },
            fonts: {
              title: "Inter",
              body: "Inter"
            }
          }
        }
      ];
      
      for (const template of templates) {
        await this.createResumeTemplate(template);
      }
    }
  }

  // User methods
  async getUser(id: number): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.id, id));
    return user;
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.username, username));
    return user;
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const [user] = await db.insert(users).values(insertUser).returning();
    return user;
  }
  
  // Resume methods
  async getResume(id: number): Promise<Resume | undefined> {
    const [resume] = await db.select().from(resumes).where(eq(resumes.id, id));
    return resume;
  }
  
  async getResumesByUserId(userId: number): Promise<Resume[]> {
    return await db.select().from(resumes).where(eq(resumes.userId, userId));
  }
  
  async createResume(insertResume: InsertResume): Promise<Resume> {
    console.log("Storage: Creating resume with data:", JSON.stringify(insertResume));
    try {
      const [resume] = await db.insert(resumes).values(insertResume).returning();
      console.log("Storage: Resume created successfully:", JSON.stringify(resume));
      return resume;
    } catch (error) {
      console.error("Storage: Error creating resume:", error);
      throw error;
    }
  }
  
  async updateResume(id: number, updateData: Partial<InsertResume>): Promise<Resume | undefined> {
    const [updatedResume] = await db
      .update(resumes)
      .set({
        ...updateData,
        updatedAt: new Date()
      })
      .where(eq(resumes.id, id))
      .returning();
    
    return updatedResume;
  }
  
  async deleteResume(id: number): Promise<boolean> {
    const result = await db.delete(resumes).where(eq(resumes.id, id)).returning();
    return result.length > 0;
  }
  
  // Template methods
  async getResumeTemplate(id: number): Promise<ResumeTemplate | undefined> {
    const [template] = await db.select().from(resumeTemplates).where(eq(resumeTemplates.id, id));
    return template;
  }
  
  async getAllResumeTemplates(): Promise<ResumeTemplate[]> {
    return await db.select().from(resumeTemplates);
  }
  
  async createResumeTemplate(template: InsertResumeTemplate): Promise<ResumeTemplate> {
    const [newTemplate] = await db.insert(resumeTemplates).values(template).returning();
    return newTemplate;
  }
  
  // Job match methods
  async getJobMatch(id: number): Promise<JobMatch | undefined> {
    const [jobMatch] = await db.select().from(jobMatches).where(eq(jobMatches.id, id));
    return jobMatch;
  }
  
  async getJobMatchesByResumeId(resumeId: number): Promise<JobMatch[]> {
    return await db.select().from(jobMatches).where(eq(jobMatches.resumeId, resumeId));
  }
  
  async createJobMatch(jobMatch: InsertJobMatch): Promise<JobMatch> {
    const [newMatch] = await db.insert(jobMatches).values(jobMatch).returning();
    return newMatch;
  }
  
  async updateJobMatch(id: number, updateData: Partial<InsertJobMatch>): Promise<JobMatch | undefined> {
    const [updatedMatch] = await db
      .update(jobMatches)
      .set(updateData)
      .where(eq(jobMatches.id, id))
      .returning();
    
    return updatedMatch;
  }
}

// Create and export the database storage instance
export const storage = new DatabaseStorage();
