import { analyzeResume, analyzeJobDescription } from './openai';
import { ResumeContent } from '@shared/schema';
import natural from 'natural';

const tokenizer = new natural.WordTokenizer();
const TfIdf = natural.TfIdf;

// Simple keyword extraction using TF-IDF
function extractKeywords(text: string, count = 10): string[] {
  if (!text || text.trim() === '') return [];
  
  const tfidf = new TfIdf();
  tfidf.addDocument(text);
  
  // Get the top N terms
  const terms: { term: string; measure: number }[] = [];
  tfidf.listTerms(0).forEach(term => {
    // Filter out numbers and single characters
    if (!/^\d+$/.test(term.term) && term.term.length > 1) {
      terms.push(term);
    }
  });
  
  return terms
    .sort((a, b) => b.measure - a.measure)
    .slice(0, count)
    .map(term => term.term);
}

// Calculate a basic ATS score based on resume content
export async function calculateATSScore(resume: ResumeContent): Promise<{
  score: number;
  suggestions: string[];
  analysis: string;
}> {
  // Use OpenAI for advanced analysis
  const openAIAnalysis = await analyzeResume(resume);
  
  return {
    score: openAIAnalysis.score,
    suggestions: openAIAnalysis.suggestions,
    analysis: openAIAnalysis.analysis
  };
}

// Calculate keyword match score between resume and job description
export async function calculateJobMatch(
  resume: ResumeContent,
  jobDescription: string
): Promise<{
  matchScore: number;
  matchedKeywords: string[];
  missingKeywords: string[];
  recommendations: string[];
}> {
  // For a more accurate analysis, use OpenAI
  const analysis = await analyzeJobDescription(jobDescription, resume);
  
  return {
    matchScore: analysis.matchScore,
    matchedKeywords: analysis.matchedKeywords,
    missingKeywords: analysis.missingKeywords,
    recommendations: analysis.recommendations
  };
}

// Improve resume sections using AI
export async function improveResumeSection(
  sectionType: string,
  sectionContent: any,
  jobDescription?: string
) {
  const { enhancedContent, suggestions } = await analyzeResume(
    { [sectionType]: sectionContent },
    jobDescription
  );
  
  return {
    enhancedContent,
    suggestions
  };
}

// Export the utilities
export default {
  calculateATSScore,
  calculateJobMatch,
  improveResumeSection,
  extractKeywords
};
