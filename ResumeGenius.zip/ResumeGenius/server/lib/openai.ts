import OpenAI from "openai";

// Initialize OpenAI client
const openai = new OpenAI({ 
  apiKey: process.env.OPENAI_API_KEY 
});

// Analyze a resume and provide suggestions for improvement
export async function analyzeResume(resumeContent: any, jobDescription?: string): Promise<{
  suggestions: string[];
  score: number;
  analysis: string;
}> {
  try {
    let prompt = `
    Analyze this resume and provide actionable suggestions for improvement:
    
    Resume: ${JSON.stringify(resumeContent)}
    
    Provide your analysis as JSON with the following properties:
    - suggestions: array of specific suggestions for improving the resume
    - score: a number between 0-100 representing how well the resume is written
    - analysis: a short summary of the resume's strengths and weaknesses
    `;

    if (jobDescription) {
      prompt += `\n\nJob Description: ${jobDescription}\n\nAlso evaluate how well the resume matches this job description.`;
    }

    const response = await openai.chat.completions.create({
      model: "gpt-4o", // the newest OpenAI model is "gpt-4o" which was released May 13, 2024. do not change this unless explicitly requested by the user
      messages: [
        {
          role: "system",
          content: "You are an expert resume analyst specializing in ATS optimization. Provide clear, actionable feedback on resumes to help job seekers improve their chances of getting past automated systems."
        },
        {
          role: "user",
          content: prompt
        }
      ],
      response_format: { type: "json_object" }
    });

    const content = response.choices[0].message.content;
    const result = content ? JSON.parse(content) : {};
    
    return {
      suggestions: result.suggestions || [],
      score: result.score || 50,
      analysis: result.analysis || "Analysis not available"
    };
  } catch (error) {
    console.error("Error analyzing resume:", error);
    return {
      suggestions: ["Failed to analyze resume. Please try again later."],
      score: 0,
      analysis: "Analysis failed due to an error"
    };
  }
}

// Generate improved content for a resume section
export async function enhanceResumeSection(
  sectionType: string, 
  sectionContent: any, 
  jobDescription?: string
): Promise<{
  enhancedContent: any;
  suggestions: string[];
}> {
  try {
    const prompt = `
    I have a resume section of type "${sectionType}" with the following content:
    
    ${JSON.stringify(sectionContent)}
    
    ${jobDescription ? `I want to optimize it for this job description: ${jobDescription}` : 'I want to enhance it to make it more compelling.'}
    
    Please provide:
    1. An enhanced version of this content that is more impactful and professional
    2. A list of suggestions for further improvements
    
    Return your response as JSON with the following properties:
    - enhancedContent: the improved version of the content
    - suggestions: array of specific suggestions for further enhancement
    `;

    const response = await openai.chat.completions.create({
      model: "gpt-4o", // the newest OpenAI model is "gpt-4o" which was released May 13, 2024. do not change this unless explicitly requested by the user
      messages: [
        {
          role: "system",
          content: "You are an expert resume writer who specializes in creating compelling, ATS-friendly content. Help improve resume sections to be more impactful and keyword-rich without fabricating experience."
        },
        {
          role: "user",
          content: prompt
        }
      ],
      response_format: { type: "json_object" }
    });

    const content = response.choices[0].message.content;
    const result = content ? JSON.parse(content) : {};
    
    return {
      enhancedContent: result.enhancedContent || sectionContent,
      suggestions: result.suggestions || []
    };
  } catch (error) {
    console.error("Error enhancing resume section:", error);
    return {
      enhancedContent: sectionContent,
      suggestions: ["Failed to enhance content. Please try again later."]
    };
  }
}

// Analyze a job description and extract key information
export async function analyzeJobDescription(
  jobDescription: string,
  resumeContent: any
): Promise<{
  matchScore: number;
  matchedKeywords: string[];
  missingKeywords: string[];
  recommendations: string[];
}> {
  try {
    const prompt = `
    Analyze this job description and resume to help optimize the resume for this specific position:
    
    Job Description: ${jobDescription}
    
    Resume: ${JSON.stringify(resumeContent)}
    
    Provide your analysis as JSON with the following properties:
    - matchScore: a number between 0-100 representing how well the resume matches the job description
    - matchedKeywords: array of keywords found in both the resume and job description
    - missingKeywords: array of important keywords from the job description that are missing in the resume
    - recommendations: array of specific recommendations to improve the resume for this job
    `;

    const response = await openai.chat.completions.create({
      model: "gpt-4o", // the newest OpenAI model is "gpt-4o" which was released May 13, 2024. do not change this unless explicitly requested by the user
      messages: [
        {
          role: "system",
          content: "You are an expert in job matching and ATS optimization. Analyze job descriptions and resumes to provide actionable insights for job seekers."
        },
        {
          role: "user",
          content: prompt
        }
      ],
      response_format: { type: "json_object" }
    });

    const content = response.choices[0].message.content;
    const result = content ? JSON.parse(content) : {};
    
    return {
      matchScore: result.matchScore || 0,
      matchedKeywords: result.matchedKeywords || [],
      missingKeywords: result.missingKeywords || [],
      recommendations: result.recommendations || []
    };
  } catch (error) {
    console.error("Error analyzing job description:", error);
    return {
      matchScore: 0,
      matchedKeywords: [],
      missingKeywords: [],
      recommendations: ["Failed to analyze job description. Please try again later."]
    };
  }
}
