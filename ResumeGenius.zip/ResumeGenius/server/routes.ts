import type { Express, Request, Response, NextFunction } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { z } from "zod";
import { 
  insertResumeSchema, 
  resumeContentSchema, 
  jobAnalysisSchema 
} from "@shared/schema";
import { calculateATSScore, calculateJobMatch } from "./lib/ats-analyzer";
import { analyzeResume, enhanceResumeSection, analyzeJobDescription } from "./lib/openai";
import { setupAuth } from "./auth";

// Middleware to check if user is authenticated
const isAuthenticated = (req: Request, res: Response, next: NextFunction) => {
  if (req.isAuthenticated()) {
    return next();
  }
  res.status(401).json({ message: "Authentication required" });
};

export async function registerRoutes(app: Express): Promise<Server> {
  // Set up authentication
  setupAuth(app);
  // API routes with /api prefix
  
  // Resume Templates
  app.get("/api/templates", async (req: Request, res: Response) => {
    try {
      const templates = await storage.getAllResumeTemplates();
      res.json(templates);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch resume templates" });
    }
  });
  
  app.get("/api/templates/:id", async (req: Request, res: Response) => {
    try {
      const id = parseInt(req.params.id);
      const template = await storage.getResumeTemplate(id);
      
      if (!template) {
        return res.status(404).json({ message: "Template not found" });
      }
      
      res.json(template);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch resume template" });
    }
  });
  
  // Resumes
  app.get("/api/resumes", isAuthenticated, async (req: Request, res: Response) => {
    try {
      const userId = req.user!.id;
      const resumes = await storage.getResumesByUserId(userId);
      res.json(resumes);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch resumes" });
    }
  });
  
  app.get("/api/resumes/:id", isAuthenticated, async (req: Request, res: Response) => {
    try {
      const id = parseInt(req.params.id);
      const resume = await storage.getResume(id);
      
      if (!resume) {
        return res.status(404).json({ message: "Resume not found" });
      }
      
      res.json(resume);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch resume" });
    }
  });
  
  app.post("/api/resumes", isAuthenticated, async (req: Request, res: Response) => {
    try {
      console.log("Creating resume with data:", JSON.stringify(req.body));
      
      // Validate request body
      const resumeData = insertResumeSchema.parse(req.body);
      console.log("Validated resume data:", JSON.stringify(resumeData));
      
      // Create resume
      const resume = await storage.createResume(resumeData);
      console.log("Created resume:", JSON.stringify(resume));
      
      res.status(201).json(resume);
    } catch (error) {
      console.error("Error creating resume:", error);
      if (error instanceof z.ZodError) {
        console.error("Validation errors:", JSON.stringify(error.errors));
        return res.status(400).json({ message: "Invalid resume data", errors: error.errors });
      }
      res.status(500).json({ message: "Failed to create resume" });
    }
  });
  
  app.put("/api/resumes/:id", isAuthenticated, async (req: Request, res: Response) => {
    try {
      const id = parseInt(req.params.id);
      const updateData = insertResumeSchema.partial().parse(req.body);
      
      const updatedResume = await storage.updateResume(id, updateData);
      
      if (!updatedResume) {
        return res.status(404).json({ message: "Resume not found" });
      }
      
      res.json(updatedResume);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: "Invalid resume data", errors: error.errors });
      }
      res.status(500).json({ message: "Failed to update resume" });
    }
  });
  
  app.delete("/api/resumes/:id", isAuthenticated, async (req: Request, res: Response) => {
    try {
      const id = parseInt(req.params.id);
      const success = await storage.deleteResume(id);
      
      if (!success) {
        return res.status(404).json({ message: "Resume not found" });
      }
      
      res.status(204).send();
    } catch (error) {
      res.status(500).json({ message: "Failed to delete resume" });
    }
  });
  
  // ATS Analysis
  app.post("/api/ats/analyze", isAuthenticated, async (req: Request, res: Response) => {
    try {
      const { resumeContent } = req.body;
      
      // Validate resume content
      const validatedContent = resumeContentSchema.parse(resumeContent);
      
      // Calculate ATS score
      const analysis = await calculateATSScore(validatedContent);
      
      res.json(analysis);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: "Invalid resume content", errors: error.errors });
      }
      res.status(500).json({ message: "Failed to analyze resume" });
    }
  });
  
  // AI Enhancement
  app.post("/api/ai/enhance", isAuthenticated, async (req: Request, res: Response) => {
    try {
      const { sectionType, sectionContent, jobDescription } = req.body;
      
      if (!sectionType || !sectionContent) {
        return res.status(400).json({ message: "Section type and content are required" });
      }
      
      const enhancement = await enhanceResumeSection(sectionType, sectionContent, jobDescription);
      
      res.json(enhancement);
    } catch (error) {
      res.status(500).json({ message: "Failed to enhance resume section" });
    }
  });
  
  // Job Matcher
  app.post("/api/job/match", isAuthenticated, async (req: Request, res: Response) => {
    try {
      const { resumeContent, jobDescription } = req.body;
      
      if (!resumeContent || !jobDescription) {
        return res.status(400).json({ message: "Resume content and job description are required" });
      }
      
      // Validate resume content
      const validatedContent = resumeContentSchema.parse(resumeContent);
      
      // Calculate job match
      const analysis = await calculateJobMatch(validatedContent, jobDescription);
      
      res.json(analysis);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: "Invalid data", errors: error.errors });
      }
      res.status(500).json({ message: "Failed to match job description" });
    }
  });
  
  app.post("/api/job/save-match", isAuthenticated, async (req: Request, res: Response) => {
    try {
      const { resumeId, jobTitle, jobDescription, analysis } = req.body;
      
      // Get user ID from authenticated user (isAuthenticated middleware ensures it exists)
      const userId = (req.user as Express.User).id;
      
      // Validate analysis
      const validatedAnalysis = jobAnalysisSchema.parse(analysis);
      
      // Save job match
      const jobMatch = await storage.createJobMatch({
        userId,
        resumeId,
        jobTitle,
        jobDescription,
        matchScore: validatedAnalysis.matchScore,
        analysis: validatedAnalysis
      });
      
      res.status(201).json(jobMatch);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: "Invalid data", errors: error.errors });
      }
      res.status(500).json({ message: "Failed to save job match" });
    }
  });

  const httpServer = createServer(app);
  return httpServer;
}
